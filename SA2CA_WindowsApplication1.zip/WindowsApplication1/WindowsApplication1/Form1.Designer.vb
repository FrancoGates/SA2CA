﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSourceConn = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtDestConn = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtClientConn = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnInit = New System.Windows.Forms.Button()
        Me.txtSQLWhere = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.txtLogPath = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPortN = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.BtnCopyMandateTemplates = New System.Windows.Forms.Button()
        Me.btnFailersReSync = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtRows = New System.Windows.Forms.TextBox()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.txtBatch = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtSourceConn
        '
        Me.txtSourceConn.Location = New System.Drawing.Point(215, 70)
        Me.txtSourceConn.Name = "txtSourceConn"
        Me.txtSourceConn.Size = New System.Drawing.Size(369, 20)
        Me.txtSourceConn.TabIndex = 0
        Me.txtSourceConn.Text = "DRIVER=IBM DB2 ODBC DRIVER - DB2COPY1;SERVER=mvsprod:446;DATABASE=FDPG;UID=sigver" & _
    ";PWD=sigver01;DBALIAS=FDPG"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label1.Location = New System.Drawing.Point(12, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Source DB Connection String"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtDestConn
        '
        Me.txtDestConn.Location = New System.Drawing.Point(215, 148)
        Me.txtDestConn.Name = "txtDestConn"
        Me.txtDestConn.Size = New System.Drawing.Size(369, 20)
        Me.txtDestConn.TabIndex = 2
        Me.txtDestConn.Text = "NA"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label2.Location = New System.Drawing.Point(12, 148)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Destination DB Connection String"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtClientConn
        '
        Me.txtClientConn.Location = New System.Drawing.Point(362, 174)
        Me.txtClientConn.Name = "txtClientConn"
        Me.txtClientConn.Size = New System.Drawing.Size(222, 20)
        Me.txtClientConn.TabIndex = 4
        Me.txtClientConn.Text = "SQL08SIGVERQA"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label3.Location = New System.Drawing.Point(12, 174)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Server Name"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnInit
        '
        Me.btnInit.Location = New System.Drawing.Point(215, 12)
        Me.btnInit.Name = "btnInit"
        Me.btnInit.Size = New System.Drawing.Size(107, 36)
        Me.btnInit.TabIndex = 6
        Me.btnInit.Text = "Start Data Copy"
        Me.btnInit.UseVisualStyleBackColor = True
        '
        'txtSQLWhere
        '
        Me.txtSQLWhere.Location = New System.Drawing.Point(215, 96)
        Me.txtSQLWhere.Name = "txtSQLWhere"
        Me.txtSQLWhere.Size = New System.Drawing.Size(369, 20)
        Me.txtSQLWhere.TabIndex = 7
        Me.txtSQLWhere.Text = "NA"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label4.Location = New System.Drawing.Point(12, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(145, 20)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "SQL Where from Source DB"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 336)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(572, 17)
        Me.ProgressBar1.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.MenuText
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Segoe Marker", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(12, 314)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 15)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Current Task: "
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(12, 359)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(572, 25)
        Me.ProgressBar2.TabIndex = 11
        '
        'txtLogPath
        '
        Me.txtLogPath.Location = New System.Drawing.Point(362, 226)
        Me.txtLogPath.Name = "txtLogPath"
        Me.txtLogPath.Size = New System.Drawing.Size(222, 20)
        Me.txtLogPath.TabIndex = 13
        Me.txtLogPath.Text = "C:\Sybrin\test1.txt"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label7.Location = New System.Drawing.Point(12, 226)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(145, 20)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Log Path"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtPortN
        '
        Me.txtPortN.Location = New System.Drawing.Point(501, 200)
        Me.txtPortN.Name = "txtPortN"
        Me.txtPortN.Size = New System.Drawing.Size(83, 20)
        Me.txtPortN.TabIndex = 15
        Me.txtPortN.Text = "53203"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label8.Location = New System.Drawing.Point(12, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(145, 20)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Port"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnCopyMandateTemplates
        '
        Me.BtnCopyMandateTemplates.Location = New System.Drawing.Point(441, 12)
        Me.BtnCopyMandateTemplates.Name = "BtnCopyMandateTemplates"
        Me.BtnCopyMandateTemplates.Size = New System.Drawing.Size(143, 36)
        Me.BtnCopyMandateTemplates.TabIndex = 17
        Me.BtnCopyMandateTemplates.Text = "Copy Mandate Templates"
        Me.BtnCopyMandateTemplates.UseVisualStyleBackColor = True
        '
        'btnFailersReSync
        '
        Me.btnFailersReSync.Location = New System.Drawing.Point(328, 12)
        Me.btnFailersReSync.Name = "btnFailersReSync"
        Me.btnFailersReSync.Size = New System.Drawing.Size(107, 36)
        Me.btnFailersReSync.TabIndex = 18
        Me.btnFailersReSync.Text = "Re-Sync Failures"
        Me.btnFailersReSync.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label6.Location = New System.Drawing.Point(12, 122)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 20)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Convert First Rows"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtRows
        '
        Me.txtRows.Location = New System.Drawing.Point(501, 122)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.Size = New System.Drawing.Size(83, 20)
        Me.txtRows.TabIndex = 20
        Me.txtRows.Text = "10"
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.BackColor = System.Drawing.SystemColors.MenuText
        Me.lblCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCount.Font = New System.Drawing.Font("Segoe Marker", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblCount.Location = New System.Drawing.Point(12, 12)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(102, 15)
        Me.lblCount.TabIndex = 21
        Me.lblCount.Text = " Accounts Processed: 0"
        '
        'txtBatch
        '
        Me.txtBatch.Location = New System.Drawing.Point(501, 252)
        Me.txtBatch.Name = "txtBatch"
        Me.txtBatch.Size = New System.Drawing.Size(83, 20)
        Me.txtBatch.TabIndex = 22
        Me.txtBatch.Text = "10"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label9.Location = New System.Drawing.Point(12, 252)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 20)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Update in Batches of"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.Nedbank_logo_2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(596, 391)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtBatch)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.txtRows)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnFailersReSync)
        Me.Controls.Add(Me.BtnCopyMandateTemplates)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtPortN)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtLogPath)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtSQLWhere)
        Me.Controls.Add(Me.btnInit)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtClientConn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtDestConn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtSourceConn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtSourceConn As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtDestConn As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtClientConn As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnInit As System.Windows.Forms.Button
    Friend WithEvents txtSQLWhere As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtLogPath As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtPortN As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents BtnCopyMandateTemplates As System.Windows.Forms.Button
    Friend WithEvents btnFailersReSync As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtRows As System.Windows.Forms.TextBox
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents txtBatch As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label

End Class
