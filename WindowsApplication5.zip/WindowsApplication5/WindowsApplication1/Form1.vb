﻿Option Strict On

Imports System.IO
Imports idmsGLib
Imports System.Data.Odbc
Imports System.Data.SqlClient
Imports SybrinMandate


Public Class Form1

    Dim sybClient As Sybrin.Client.Client

    Private Sub btnInit_Click(sender As Object, e As EventArgs) Handles btnInit.Click

        Dim ODBCcon As OdbcConnection
        Dim ReturnVal As Long
        'Dim SybCon As SqlConnection
        Dim lvSQL As String
        Dim SourceCommand As OdbcCommand
        Dim TotalAccounts As Integer
        Dim AccountCount As Integer = 0
        Dim HappySynced As Integer = 0
        Dim OdbcDataAdap As OdbcDataAdapter
        Dim GroupList As ArrayList = New ArrayList

        Dim SV00Accounts As DataTable
        'Dim SV03SGNTYCARD As DataTable
        Dim SV01SGNTY As DataTable
        Dim SV05SGNTYAC As DataTable
        Dim SV07MNDTERLE As DataTable
        Dim SV09MNDTERLEAC As DataTable

        Dim SV05BASE As DataTable
        Dim SV07BASE As DataTable
        Dim SVDataRow() As DataRow
        Dim lvSQLAccounts As String = "WHERE"
        Dim lvAccountsCounts As Integer = 0
        Dim lvIndexCount As Integer = 0

        'Fields to be mapped - will be popluated with the details of the Current Account
        '--------------------------------------------------------------------------------
        Dim CurrentAccount As String
        Dim CISNumber As String
        Dim SigCardsArrayL As New ArrayList
        Dim SigMembers As New ArrayList
        Dim SigMandates As New ArrayList


        '------------------------------------------------------------------------
        'Processing Start Point
        '------------------------------------------------------------------------
        ManageProgressBar(0, 1, "Check Start Run", -1, -1)

        If Not CheckStart() = True Then

            WriteLog("Checkstart Failed")
            FormReset()
            MessageBox.Show("CheckStart has Failed - All fields must be populated", "CheckStart", MessageBoxButtons.OK)
        Else
            ManageProgressBar(1, 1, "Check Start Ready", -1, -1)
            WriteLog("Checkstart Success")

            WriteLog("Attempting To Connect to Source DB")
            ManageProgressBar(0, 3, "Attempting To Connect to Source DB", -1, -1)

            'Attempt to connect to Source DB2 database
            '--------------------------------------------------------------------
            Try

                ODBCcon = New OdbcConnection(txtSourceConn.Text)
                ODBCcon.Open()

            Catch ex As Exception
                WriteLog("Could not Connect to Source: " & ex.ToString())
                FormReset()
                MessageBox.Show("Could not Connect to the Source Database, please check the connection details", "Failed to Connect", MessageBoxButtons.OK)
                Return
            End Try

            WriteLog("Attempting to Connect to Sybrin DB")
            ManageProgressBar(1, 3, "Attempting to Connect to Sybrin DB", -1, -1)

            'attempt to Connect to Destination DB
            '---------------------------------------------------------------------
            'Try
            '    SybCon = New SqlConnection(txtDestConn.Text)
            '    SybCon.Open()

            'Catch ex As Exception
            '    WriteLog("Could not Connect to Sybrin Database: " & ex.ToString())
            '    FormReset()
            '    MessageBox.Show("Could not Connect to the Sybrin Database, please check the connection details", "Failed to Connect", MessageBoxButtons.OK)
            '    Return
            'End Try

            ManageProgressBar(2, 3, "Connecting to Sybrin Client", -1, -1)

            'Attempt to connect to Sybrin.
            '---------------------------------------------------------------------
            Try

                If sybClient Is Nothing Then sybClient = New Sybrin.Client.Client
                If Not sybClient.LoggedOn Then
                    ReturnVal = sybClient.Logon(Sybrin.Common.SybrinModule.Scheduler, "Wikus", "123", txtClientConn.Text, CInt(txtPortN.Text))

                    If ReturnVal = 0 Then
                        WriteLog("Connected to Sybrin Client")
                    Else
                        WriteLog("Could not Connect to Sybrin")
                    End If
                Else
                    WriteLog("Sybrin Client is Logged On")
                End If

            Catch ex As Exception
                WriteLog("Could not Connect to Sybrin: " & ex.ToString())
                FormReset()
                MessageBox.Show("Could not Connect to the Sybrin, please check the connection details", "Failed to Connect", MessageBoxButtons.OK)
                Return
            End Try

            WriteLog("Retrieve the Amount of Accounts to be Converted")
            ManageProgressBar(3, 3, "Retrieve the Amount of Accounts to be Converted", -1, -1)

            Try

                'Attempt to get the total amount of Accounts to Upload to Sybrin
                '-------------------------------------------------------------------
                If txtSQLWhere.TextLength < 3 Then
                    lvSQL = "Select Count(*) as CountAcc from NSVD99.SV00_ACCOUNT"
                Else
                    If Microsoft.VisualBasic.Left(txtSQLWhere.Text, 5).ToLower() = "where" Then
                        lvSQL = "Select Count(*) as CountAcc from NSVD99.SV00_ACCOUNT " & txtSQLWhere.Text
                    Else
                        lvSQL = "Select Count(*) as CountAcc from NSVD99.SV00_ACCOUNT WHERE " & txtSQLWhere.Text
                    End If
                End If

                'Check if we only need to do the first x amount of Accounts
                If Not txtRows.Text.ToUpper() = "ALL" Then
                    lvSQL = lvSQL & " fetch first " & txtRows.Text & " rows only"
                End If

                WriteLog("Sql:" & lvSQL)

                'create the reader to get the total
                SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                Dim SourceRead As OdbcDataReader = SourceCommand.ExecuteReader()
                While SourceRead.Read = True
                    TotalAccounts = CInt(SourceRead.Item("CountAcc"))
                End While

                WriteLog("Value Retrieved: " & TotalAccounts.ToString())
                ManageProgressBar(3, 3, "", -1, -1)

                'check with the user if the count seems to be correct.
                Dim ConfirmDo As DialogResult = MessageBox.Show("You are about to transfer " & TotalAccounts.ToString() & " Accounts to Sybrin, Are you Sure?", "Conversion Confirm", MessageBoxButtons.YesNo)

                If ConfirmDo = Windows.Forms.DialogResult.Yes Then

                    WriteLog("User Confirmed that the Accounts are to be Processed")
                    ManageProgressBar(0, 1, "Retrieve Account List", -1, -1)

                    'The user can process all the accounts without a where.
                    If txtSQLWhere.TextLength < 3 Then
                        lvSQL = "Select SV00_AC_NUM, SV00_CIS_NUM as CountAcc from NSVD99.SV00_ACCOUNT"
                    Else
                        If Microsoft.VisualBasic.Left(txtSQLWhere.Text, 5).ToLower() <> "where" Then
                            lvSQL = "Select SV00_AC_NUM, SV00_CIS_NUM as CountAcc from NSVD99.SV00_ACCOUNT WHERE " & txtSQLWhere.Text
                        Else
                            lvSQL = "Select SV00_AC_NUM, SV00_CIS_NUM as CountAcc from NSVD99.SV00_ACCOUNT " & txtSQLWhere.Text
                        End If
                    End If

                    'Check if we only need to do the first x amount of Accounts
                    If Not txtRows.Text.ToUpper() = "ALL" Then
                        lvSQL = lvSQL & " fetch first " & txtRows.Text & " rows only"
                    End If

                    'Get the list of Account and CIS numbers to work with
                    SourceCommand.Dispose()
                    SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                    OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                    SV00Accounts = New DataTable()
                    OdbcDataAdap.Fill(SV00Accounts)

                    WriteLog("Account List Retrieved and filled into Data table SV00Accounts")
                    ManageProgressBar(1, 1, "", -1, -1)


                    'Each account must be transferred Seperately
                    If SV00Accounts.Rows.Count > 0 Then

                        TotalAccounts = SV00Accounts.Rows.Count

                        WriteLog("There were accounts found to be processed")
                        ManageProgressBar(1, 15, "Processing Account Start", AccountCount, TotalAccounts)

                        If Not txtSQLWhere.TextLength > 3 Then
                            'We are dealing with a fresh account Migration - clear the existing Savings Accounts before starting.
                            ManageProgressBar(0, 1, "Clearing All Existing Savings Accounts", 0, 0)
                            If Not ClearData() = True Then
                                'Do not add the accounts if the delete failed.
                                Return
                            End If
                            ManageProgressBar(1, 1, "Accounts Cleared", 0, 0)
                        End If


                        '=====================================================
                        'Get the base Data Tables 
                        'Takes too long doing this lookup in the Source Per account - doing it in Batches
                        '=====================================================

                        'Build the Account where to fetch accounts in Batches.
                        If TotalAccounts >= CInt(txtBatch.Text) Then

                            While lvAccountsCounts < CInt(txtBatch.Text)
                                lvSQLAccounts = lvSQLAccounts & " SV05_AC_NUM = '" & SV00Accounts.Rows(lvAccountsCounts).Item(0).ToString() & "' OR"
                                lvAccountsCounts = lvAccountsCounts + 1
                                lvIndexCount = lvIndexCount + 1
                            End While


                            lvAccountsCounts = 0

                        Else
                            For Each Account As DataRow In SV00Accounts.Rows
                                lvSQLAccounts = lvSQLAccounts & " SV05_AC_NUM = '" & Account("SV00_AC_NUM").ToString() & "' OR"
                            Next

                        End If

                        If lvSQLAccounts.EndsWith("OR") Then
                            lvSQLAccounts = Trim(Microsoft.VisualBasic.Left(lvSQLAccounts, lvSQLAccounts.Length - 2))
                        End If

                        'Select Batches from Source
                        '-----------------------------------

                        ManageProgressBar(1, 3, "Get Base Data From Source - SV05", 0, 0)

                        'SV05BASE
                        SV05BASE = New DataTable()
                        SourceCommand.Dispose()
                        OdbcDataAdap.Dispose()

                        lvSQL = "Select SV05_AC_NUM, SV05_SGNTY_ID, SV05_CPTRD_DTE, SV05_EXP_EFCT_DTE, SV05_DEL_RECV_DTE, SV05_UPDT_DTE, SV05_CTGR_TYP_CDE from NSVD99.SV05_AC_SGNTY_ALCT " & lvSQLAccounts  ' where Right(SV05_AC_NUM, 10) = '" & 1121005306 & "'"

                        WriteLog("Get Base Member Info from Source To load into SV05BASE: " & lvSQL)

                        'populate the data table
                        SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                        OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                        OdbcDataAdap.Fill(SV05BASE)

                        If Not SV05BASE.Rows.Count > 0 Then
                            WriteLog("Unable to Retrieve Base Member Info SV05BASE from Source")
                            Return
                        Else
                            WriteLog("SV05BASE Member Info Retrieved")
                        End If

                        ManageProgressBar(2, 3, "Get Base Data From Source - SV07", 0, 0)

                        'SV07BASE 
                        SV07BASE = New DataTable()
                        SourceCommand.Dispose()
                        OdbcDataAdap.Dispose()

                        lvSQL = "Select SV07_AC_NUM, SV07_FROM_AMT, SV07_TO_AMT, SV07_CPTR_MNDT_DTE, SV07_MNDT_EXP_DTE, SV07_UPDT_MNDT_DTE, SV07_MNDT_RULE_ID FROM NSVD99.SV07_AC_MNDT_SRVC " & Replace(Replace(lvSQLAccounts, "SV05_AC_NUM", "SV07_AC_NUM"), "from NSVD99.SV05_AC_SGNTY_ALCT", "FROM NSVD99.SV07_AC_MNDT_SRVC")

                        WriteLog("Get Base Member Info from Source To load into SV07BASE: " & lvSQL)

                        'Populate the Table
                        SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                        OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                        OdbcDataAdap.Fill(SV07BASE)

                        If Not SV07BASE.Rows.Count > 0 Then
                            WriteLog("Unable to Retrieve Base Member Info SV07BASE from Source")
                            Return
                        Else
                            WriteLog("SV07BASE Member Info Retrieved")
                        End If

                        ManageProgressBar(3, 3, "Get Base Data From Source - DONE!", 0, 0)

                        '=====================================================

                        'get the Groups and Guids From Sybrin
                        GroupList = AddSAGroups()
                        If Not GroupList.Count > 0 Then
                            WriteLog("Could not retrieve Groups and Group Guids from Sybrin, Account will not be processed")
                            Return
                        End If

                        '---------------------------------------------------
                        'Actual Account LOOP To get the account information
                        '---------------------------------------------------
                        For Each row As DataRow In SV00Accounts.Rows

                            CurrentAccount = Microsoft.VisualBasic.Right(row.Item(0).ToString(), 10)
                            CISNumber = row.Item(1).ToString()

                            'Check if we need to fect the next batch
                            If lvAccountsCounts >= CInt(txtBatch.Text) Then

                                'dispose of the old Base Tables
                                SV05BASE.Dispose()
                                SV07BASE.Dispose()

                                If lvIndexCount + CInt(txtBatch.Text) >= TotalAccounts Then
                                    lvAccountsCounts = CInt(txtBatch.Text) - (TotalAccounts - lvIndexCount)
                                Else
                                    lvAccountsCounts = 0
                                End If

                                lvSQLAccounts = ""

                                While lvAccountsCounts <= CInt(txtBatch.Text)
                                    If Not lvIndexCount >= TotalAccounts Then ' the 0  based Index meaning the last one was actually done already
                                        lvSQLAccounts = lvSQLAccounts & " SV05_AC_NUM = '" & SV00Accounts.Rows(lvIndexCount).Item(0).ToString() & "' OR"
                                        lvIndexCount = lvIndexCount + 1
                                        lvAccountsCounts = lvAccountsCounts + 1
                                    Else
                                        lvAccountsCounts = lvAccountsCounts + 1 ' exit
                                    End If
                                End While

                                lvAccountsCounts = 0

                                If lvSQLAccounts.EndsWith("OR") Then
                                    lvSQLAccounts = Trim(Microsoft.VisualBasic.Left(lvSQLAccounts, lvSQLAccounts.Length - 2))
                                End If

                                If Not lvSQLAccounts.StartsWith("WHERE") Then
                                    lvSQLAccounts = "WHERE " & lvSQLAccounts
                                End If

                                'Select Batches from Source
                                '-----------------------------------

                                ManageProgressBar(1, 3, "Get Base Data From Source - SV05", 0, 0)

                                'SV05BASE
                                SV05BASE = New DataTable()
                                SourceCommand.Dispose()
                                OdbcDataAdap.Dispose()

                                lvSQL = "Select SV05_AC_NUM, SV05_SGNTY_ID, SV05_CPTRD_DTE, SV05_EXP_EFCT_DTE, SV05_DEL_RECV_DTE, SV05_UPDT_DTE, SV05_CTGR_TYP_CDE from NSVD99.SV05_AC_SGNTY_ALCT " & lvSQLAccounts  ' where Right(SV05_AC_NUM, 10) = '" & 1121005306 & "'"

                                WriteLog("Get Base Member Info from Source To load into SV05BASE: " & lvSQL)

                                'populate the data table
                                SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                                OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                                OdbcDataAdap.Fill(SV05BASE)

                                If Not SV05BASE.Rows.Count > 0 Then
                                    WriteLog("Unable to Retrieve Base Member Info SV05BASE from Source")
                                    Return
                                Else
                                    WriteLog("SV05BASE Member Info Retrieved")
                                End If

                                ManageProgressBar(2, 3, "Get Base Data From Source - SV07", 0, 0)

                                'SV07BASE 
                                SV07BASE = New DataTable()
                                SourceCommand.Dispose()
                                OdbcDataAdap.Dispose()

                                lvSQL = "Select SV07_AC_NUM, SV07_FROM_AMT, SV07_TO_AMT, SV07_CPTR_MNDT_DTE, SV07_MNDT_EXP_DTE, SV07_UPDT_MNDT_DTE, SV07_MNDT_RULE_ID FROM NSVD99.SV07_AC_MNDT_SRVC " & Replace(Replace(lvSQLAccounts, "SV05_AC_NUM", "SV07_AC_NUM"), "from NSVD99.SV05_AC_SGNTY_ALCT", "FROM NSVD99.SV07_AC_MNDT_SRVC")

                                WriteLog("Get Base Member Info from Source To load into SV07BASE: " & lvSQL)

                                'Populate the Table
                                SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                                OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                                OdbcDataAdap.Fill(SV07BASE)

                                If Not SV07BASE.Rows.Count > 0 Then
                                    WriteLog("Unable to Retrieve Base Member Info SV07BASE from Source")
                                    Return
                                Else
                                    WriteLog("SV07BASE Member Info Retrieved")
                                End If

                            Else
                                'we dont need to fect the next batch yet - count
                                lvAccountsCounts = lvAccountsCounts + 1
                            End If

                            WriteLog("Processing Account Start : " & CurrentAccount)

                            '------------------------------------------------------------
                            'MANDATE FORMS
                            'Get the Mandate Forms associated with the current Account.
                            '------------------------------------------------------------
                            '///////////////\\\\\\\\This Table was found to no longer exist in the actual Prod Database, 
                            '//////////////\\\\\\\\\\\The Required info will be retrieved from the Mandate Rules

                            'lvSQL = "Select SV03_AC_NUM, SV03_CPTRD_DTE, SV03_UPDT_DTE from NSVD99.SV03_SGNTY_CARD where SV03_AC_NUM = '" & CurrentAccount & "'"

                            'ManageProgressBar(2, 15, "Get Signature Cards for the Account", AccountCount, TotalAccounts)
                            'WriteLog("About to retrieve list of Signature Cards")
                            'WriteLog(lvSQL)

                            'SourceCommand.Dispose()
                            'SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                            'OdbcDataAdap.Dispose()
                            'OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                            'SV03SGNTYCARD = New DataTable()
                            'OdbcDataAdap.Fill(SV03SGNTYCARD)

                            'WriteLog("Data Table SV03SGNTYCARD has been filled")

                            ''loop through the results and add results into arraylist
                            ''Load each result for this account into a Arraylist from where we can get it later.
                            'If SV03SGNTYCARD.Rows.Count > 0 Then

                            '    WriteLog("Cards Found, About to Add Card Records to Arraylist")

                            '    For Each cardrow As DataRow In SV03SGNTYCARD.Rows

                            '        SigCardsArrayL.Add(cardrow("SV03_AC_NUM").ToString() & "," & cardrow("SV03_CPTRD_DTE").ToString() & "," & cardrow("SV03_UPDT_DTE").ToString())
                            '        WriteLog("Added Card to Arraylist")

                            '    Next

                            'Else
                            '    'No Card Records returned - Process will Proceed regardless
                            '    WriteLog("No Cards Returned - Process will go to next step")

                            'End If

                            'WriteLog("All Card Records added to ArrayList")
                            ManageProgressBar(3, 15, "Locate the Mandate Members for the account", AccountCount, TotalAccounts)

                            '------------------------------------------------------------------------
                            'ACCOUNT MEMBERS
                            'Attempt to get all the mandate members and their relevant information
                            '------------------------------------------------------------------------

                            SV01SGNTY = New DataTable()
                            SV05SGNTYAC = New DataTable()
                            SV05SGNTYAC = SV05BASE.Clone()

                            'lvSQL = "Select SV05_SGNTY_ID, SV05_CPTRD_DTE, SV05_EXP_EFCT_DTE, SV05_DEL_RECV_DTE, SV05_UPDT_DTE, SV05_CTGR_TYP_CDE from NSVD99.SV05_AC_SGNTY_ALCT where Right(SV05_AC_NUM, 10) = '" & CurrentAccount & "'"

                            WriteLog("Reading Required information from Base Data Table - SV05BASE")

                            SVDataRow = SV05BASE.Select("SV05_AC_NUM LIKE '*" & CurrentAccount & "'")
                            For Each SVRow As DataRow In SVDataRow
                                SV05SGNTYAC.ImportRow(SVRow)
                            Next

                            WriteLog("Data Table SV05SGNTYAC has been Filled")

                            'Loop through the members that were returned to get the additionally required info
                            If SV05SGNTYAC.Rows.Count > 0 Then

                                For Each MemberRow As DataRow In SV05SGNTYAC.Rows

                                    lvSQL = "Select SV01_ID_NUM, SV01_SNAME_TXT, SV01_PASSPRT_NUM, SV01_SGNTY_CIS_NO, SV01_INTL_TXT, SV01_STS_CDE, SV01_IFN_DISK_ID, SV01_IFN_DOC_ID, SV01_P_IFN_DISK_ID, SV01_P_IFN_DOC_ID from NSVD99.SV01_SGNTY WHERE SV01_SGNTY_ID = " & MemberRow("SV05_SGNTY_ID").ToString() & " fetch first 1 rows only"

                                    WriteLog("SQL used to get the Member information:" & lvSQL)

                                    SourceCommand.Dispose()
                                    OdbcDataAdap.Dispose()

                                    'Populate the data table.
                                    SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                                    OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                                    OdbcDataAdap.Fill(SV01SGNTY)

                                    WriteLog("Data Table SV01SGNTY has been filled")

                                    If SV01SGNTY.Rows.Count > 0 Then

                                        'Add Member information to the Arraylist
                                        WriteLog("Adding Members to the Members Arraylist")

                                        For Each MemberRow2 As DataRow In SV01SGNTY.Rows

                                            SigMembers.Add(MemberRow2("SV01_ID_NUM").ToString() & "," & MemberRow2("SV01_PASSPRT_NUM").ToString() & "," & MemberRow2("SV01_SNAME_TXT").ToString().Trim() & " " & MemberRow2("SV01_INTL_TXT").ToString().Trim() _
                                                            & "," & MemberRow2("SV01_SGNTY_CIS_NO").ToString() & "," & MemberRow2("SV01_STS_CDE").ToString() & "," & MemberRow2("SV01_IFN_DISK_ID").ToString() & "," & MemberRow2("SV01_IFN_DOC_ID").ToString() _
                                                            & "," & MemberRow2("SV01_P_IFN_DISK_ID").ToString() & "," & MemberRow2("SV01_P_IFN_DOC_ID").ToString() & "," _
                                                            & MemberRow("SV05_CPTRD_DTE").ToString() & "," & MemberRow("SV05_UPDT_DTE").ToString() & "," & MemberRow("SV05_EXP_EFCT_DTE").ToString() _
                                                            & "," & MemberRow("SV05_DEL_RECV_DTE").ToString() & "," & MemberRow("SV05_CTGR_TYP_CDE").ToString())

                                            WriteLog("Member Added Successfully - Member ID: " & MemberRow("SV05_SGNTY_ID").ToString() & " Member Name: " & MemberRow2("SV01_SNAME_TXT").ToString().Trim() & " " & MemberRow2("SV01_INTL_TXT").ToString().Trim())

                                        Next

                                    Else

                                        WriteLog("Could not Retrieve further Member Details - Member will not be added")

                                    End If

                                Next

                            Else
                                WriteLog("No Signatories Found for this account (" & CurrentAccount & ") and this CIS number (" & CISNumber & ").")

                            End If

                            '-------------------------------------------------------------------------------
                            'MANDATE RULE
                            'Attempt to get the Mandate Rule Information.
                            '------------------------------------------------------------------------------

                            WriteLog("Get the Mandate Rule Information")
                            ManageProgressBar(4, 15, "Retrieve the Mandate Rule Information from the Base Data Table - SV07BASE", AccountCount, TotalAccounts)

                            SV07MNDTERLE = New DataTable()
                            SV09MNDTERLEAC = New DataTable()
                            SV07MNDTERLE = SV07BASE.Clone()

                            'lvSQL = "Select SV07_FROM_AMT, SV07_TO_AMT, SV07_CPTR_MNDT_DTE, SV07_MNDT_EXP_DTE, SV07_UPDT_MNDT_DTE, SV07_MNDT_RULE_ID FROM NSVD99.SV07_AC_MNDT_SRVC WHERE RIGHT(SV07_AC_NUM,10) = '" & CurrentAccount & "'"

                            SVDataRow = SV07BASE.Select("SV07_AC_NUM LIKE '*" & CurrentAccount & "'")
                            For Each SVrow As DataRow In SVDataRow
                                SV07MNDTERLE.ImportRow(SVrow)
                            Next

                            WriteLog("SV07MNDTERLE has been Filled")

                            If SV07MNDTERLE.Rows.Count > 0 Then
                                'Found the Mandate Rule
                                WriteLog("Mandate Rules have been identified and can be added.")

                                'loop through the returned items and add them
                                For Each MandateRule As DataRow In SV07MNDTERLE.Rows

                                    SourceCommand.Dispose()
                                    OdbcDataAdap.Dispose()

                                    '---------------------------------------------------------------------------------------------------
                                    'Add the Signature Card Data - Since SV03 does not exist in Prod we will use the Mandate Details.
                                    SigCardsArrayL.Add(CurrentAccount.ToString() & "," & MandateRule("SV07_CPTR_MNDT_DTE").ToString() & "," & MandateRule("SV07_UPDT_MNDT_DTE").ToString())

                                    WriteLog("Added Card to Arraylist using SV07")
                                    '---------------------------------------------------------------------------------------------------

                                    lvSQL = "Select SV09_MND_RULE_DESC, SV09_SLCT_CRT_DESC, SV09_SLCT_SIGN_TOT FROM  NSVD99.SV09_MNDT_RULE WHERE SV09_MNDT_RULE_ID = '" & MandateRule("SV07_MNDT_RULE_ID").ToString() & "'"

                                    WriteLog("SQL to get further Mandate Rule Details: " & lvSQL)

                                    SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                                    OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                                    OdbcDataAdap.Fill(SV09MNDTERLEAC)

                                    WriteLog("SV09MNDTRLEAC has been filled")

                                    If SV09MNDTERLEAC.Rows.Count > 0 Then

                                        For Each MandateRule2 As DataRow In SV09MNDTERLEAC.Rows

                                            SigMandates.Add(MandateRule2("SV09_MND_RULE_DESC").ToString() & "," & MandateRule2("SV09_SLCT_CRT_DESC").ToString() & "," & MandateRule2("SV09_SLCT_SIGN_TOT").ToString() & "," _
                                                            & MandateRule("SV07_FROM_AMT").ToString() & "," & MandateRule("SV07_TO_AMT").ToString() & "," & MandateRule("SV07_CPTR_MNDT_DTE").ToString() & "," _
                                                            & MandateRule("SV07_MNDT_EXP_DTE").ToString() & "," & MandateRule("SV07_UPDT_MNDT_DTE").ToString() & "," & MandateRule("SV07_MNDT_RULE_ID").ToString())

                                            WriteLog("Mandate Rule Added")


                                        Next

                                        WriteLog("All Card Records added to ArrayList")
                                        WriteLog("All Mandate Rules have been Added")

                                    Else
                                        WriteLog("Could not retrieve the Mandate Text Details fo Mandate ID")

                                    End If

                                Next

                            Else

                                'Could not find the Mandate Rule
                                WriteLog("Could not locate mandate rule for account number: " & CurrentAccount)

                            End If

                            WriteLog("Start the SYNC Update process")
                            ManageProgressBar(5, 15, "Start the SYNC Update Process", AccountCount, TotalAccounts)

                            '------------------------------------------------------------------------------------------------------------
                            'Start the Update Sync Process.
                            '------------------------------------------------------------------------------------------------------------

                            If IndexManager(CurrentAccount, CISNumber, SigCardsArrayL, SigMembers, SigMandates, GroupList) = True Then
                                'Account Successfully Synced to Sybrin.
                                WriteLog("Account has been Successfully Synced to Sybrin")
                                ManageProgressBar(15, 15, "Account Synced Successfully", -1, -1)
                                HappySynced = HappySynced + 1

                                lblCount.Text = "Accounts Processed: " & HappySynced.ToString()

                            Else

                                'Account failed to be correctly Synced to Sybrin.

                                If Not AccountSyncFailure(CurrentAccount) = True Then
                                    'try again
                                    AccountSyncFailure(CurrentAccount)
                                End If

                            End If

                            'Reset for next account to use.
                            AccountCount = AccountCount + 1
                            If SigCardsArrayL.Count > 0 Then SigCardsArrayL.Clear()
                            If SigMembers.Count > 0 Then SigMembers.Clear()
                            If SigMandates.Count > 0 Then SigMandates.Clear()
                            SV01SGNTY.Dispose()
                            'SV03SGNTYCARD.Dispose()
                            SV05SGNTYAC.Dispose()
                            SV07MNDTERLE.Dispose()
                            SV09MNDTERLEAC.Dispose()

                        Next row ' -- Move to the next account -- 

                        WriteLog("Account Sync has completed and a total of " & HappySynced.ToString() & " accounts have been Synced to Sybrin out of " & TotalAccounts.ToString() & ".")
                        FormReset()

                    Else

                        WriteLog("No Accounts were Returned")
                        FormReset()
                    End If

                    'DONE With the Conversion.
                    MessageBox.Show("Convesion has completed, " & vbCrLf & HappySynced.ToString() & " Accounts have been Converted of " & AccountCount.ToString() & " that were discovered")
                    WriteLog("--------------------------------------------------------------------------" & vbCrLf & "Convesion has completed, " & vbCrLf & HappySynced.ToString() & " Accounts have been Converted of " & AccountCount.ToString() & " that were discovered")
                    WriteLog("--------- END ------ END ------ END ------------")

                    SV00Accounts.Dispose()
                    ODBCcon.Close()


                Else

                    WriteLog("User Cancelled the Process")
                    FormReset()
                End If

            Catch ex As Exception
                WriteLog("An error has occured: " & ex.ToString())
                FormReset()
                ODBCcon.Close()
                'SybCon.Close()
            End Try

        End If

    End Sub

    Private Sub ManageProgressBar(ByVal ValuePB1 As Integer, ByVal TotalPB1 As Integer, ByVal Curtask As String, ByVal ValuePB2 As Integer, ByVal TotalPB2 As Integer)

        ProgressBar1.Minimum = 0
        ProgressBar2.Minimum = 0
        ProgressBar1.Style = ProgressBarStyle.Continuous
        ProgressBar2.Style = ProgressBarStyle.Continuous
        ProgressBar1.Step = ValuePB1
        ProgressBar2.Step = ValuePB2

        'TaskBar
        If Curtask <> "" Then
            Label5.Text = "Current Task: " & Curtask
        End If
        If Not TotalPB1 < 0 Then
            ProgressBar1.Maximum = TotalPB1

        End If
        If Not ValuePB1 < 0 And ValuePB1 <= ProgressBar1.Maximum Then
            ProgressBar1.Value = 0
            ProgressBar1.PerformStep()
        End If

        'Summary Bar
        If Not TotalPB2 < 0 Then
            ProgressBar2.Maximum = TotalPB2
        End If
        If Not ValuePB2 < 0 And ValuePB2 <= ProgressBar2.Maximum Then
            ProgressBar2.Value = 0
            ProgressBar2.PerformStep()
        End If

        ProgressBar2.Refresh()
        ProgressBar1.Refresh()

        Application.DoEvents()

    End Sub

    Private Sub FormReset()
        txtClientConn.Enabled = True
        txtDestConn.Enabled = True
        txtLogPath.Enabled = True
        txtSourceConn.Enabled = True
        txtSQLWhere.Enabled = True
        txtPortN.Enabled = True
        txtBatch.Enabled = True
        txtSQLWhere.Text = "NA"
        txtRows.Text = "All"
        txtRows.Enabled = True
        btnInit.Enabled = True
        BtnCopyMandateTemplates.Enabled = True
        btnFailersReSync.Enabled = True
        ManageProgressBar(0, 0, "Awaiting Task", 0, 0)
    End Sub

    Private Sub WriteLog(ByVal Message As String)

        Try

            If Not txtLogPath.Text = "NOLOG" Then

                Me.Update()

                Dim sw As StreamWriter
                Dim fs As FileStream
                Dim LogFile As FileInfo

                If (Not File.Exists(txtLogPath.Text)) Then

                    fs = File.Create(txtLogPath.Text)
                    fs.Dispose()
                    sw = File.AppendText(txtLogPath.Text)
                    sw.WriteLine(DateTime.Now().ToString() & " - " & Message)

                Else

                    LogFile = New FileInfo(txtLogPath.Text)

                    If LogFile.Length / 1024 / 1024 > 1 Then '1MB

                        txtLogPath.Text = Microsoft.VisualBasic.Left(txtLogPath.Text, txtLogPath.TextLength - 5) & _
                            (CInt(Microsoft.VisualBasic.Right(Replace(txtLogPath.Text, ".txt", ""), 1)) + 1).ToString() & ".txt"

                        fs = File.Create(txtLogPath.Text)
                        fs.Dispose()
                        sw = File.AppendText(txtLogPath.Text)
                        sw.WriteLine(DateTime.Now().ToString() & " - " & Message)

                    Else

                        sw = File.AppendText(txtLogPath.Text)
                        sw.WriteLine(DateTime.Now().ToString() & " - " & Message)

                    End If

                End If

                sw.Dispose()

            End If

        Catch ex As Exception
            'MsgBox("Error Creating Log File")

        End Try

    End Sub

    Private Function CheckStart() As Boolean
        Dim lvStartOk = True

        If Not txtClientConn.TextLength > 0 Then
            lvStartOk = False
        Else
            txtClientConn.Enabled = False
        End If

        If Not txtDestConn.TextLength > 0 Then
            lvStartOk = False
        Else
            txtDestConn.Enabled = False
        End If

        If Not txtSourceConn.TextLength > 0 Then
            lvStartOk = False
        Else
            txtSourceConn.Enabled = False
        End If

        If Not txtLogPath.TextLength > 0 Then
            lvStartOk = False
        Else
            txtLogPath.Enabled = False
        End If

        If Not txtSQLWhere.TextLength > 0 Then
            lvStartOk = False
        Else
            txtSQLWhere.Enabled = False
        End If

        If Not txtPortN.TextLength > 0 Then
            lvStartOk = False
        Else
            txtPortN.Enabled = False
        End If

        If Not txtRows.TextLength > 0 Then
            lvStartOk = False
        Else
            txtRows.Enabled = False
        End If

        If Not txtBatch.TextLength > 0 Then
            lvStartOk = False
        Else
            txtBatch.Enabled = False
        End If

        If lvStartOk = True Then
            BtnCopyMandateTemplates.Enabled = False
            btnFailersReSync.Enabled = False
            btnInit.Enabled = False
        End If

        Return lvStartOk
    End Function

    Private Function IndexManager(ByVal AccountNumber As String, ByVal CISNumber As String, ByVal SigCards As ArrayList _
                        , ByVal SigMembers As ArrayList, ByVal SigMandates As ArrayList, ByVal GroupList As ArrayList) As Boolean

        Dim SyncSuccess As Boolean = True

        Try

            ManageProgressBar(6, 15, "Clear Existing Data", -1, -1)

            'Only clear on a per account basis when we working with Specific accounts like Re-Sync of Failed accounts
            If txtSQLWhere.TextLength > 3 Then
                If Not ClearAccountData(AccountNumber) = True Then
                    'dont add if you cant clear first - Avoid Duplicating Data
                    SyncSuccess = False
                    Return SyncSuccess
                End If

            End If

            'Start Inserting the Account Information.
            '===============================================================

            ManageProgressBar(7, 15, "SYNC Account Number", -1, -1)

            'STEP 1 --- SYNC the Account Number information
            If SyncSIGAccounts(AccountNumber, CISNumber) Then
                WriteLog("Account Number Added to Sybrin")

                ManageProgressBar(8, 15, "SYNC Captured Signature Cards", -1, -1)

                'STEP 2 --- SYNC Signature Card Information
                If SyncSIGCards(SigCards, AccountNumber) Then
                    WriteLog("Signature Cards Added to Sybrin")

                    ManageProgressBar(9, 15, "Sync Mandate Members", -1, -1)

                    'STEP 3 --- SYNC Mandate Member Information
                    If SyncMandateMembers(AccountNumber, SigMembers, GroupList) Then
                        WriteLog("Signatory Members Added to Sybrin")

                        ManageProgressBar(10, 15, "Sync Mandate Rule", -1, -1)

                        'STEP 4 --- SYNC Mandate Rule Information
                        If SyncSIGMandateRule(SigMandates, AccountNumber, GroupList) Then

                            ManageProgressBar(11, 15, "Account Info Sync Success!", -1, -1)

                        Else
                            WriteLog("Mandate Rules Could not be added to Sybrin")
                            SyncSuccess = False
                        End If

                    Else
                        WriteLog("Signatory Members could not be added to Sybrin")
                        SyncSuccess = False
                    End If

                Else
                    WriteLog("Signature Cards were not added to Sybrin")
                    SyncSuccess = False
                End If

            Else
                WriteLog("Account Number could not be added to Sybrin")
                SyncSuccess = False
            End If

            'Return the Base Result
            Return SyncSuccess

        Catch ex As Exception
            WriteLog("An Error occured in Index Manager" & ex.ToString())
            Return False
        End Try

    End Function

    Private Function ExecuteSync(ByVal SQL As String, ByVal DocNo As String) As Boolean
        Try

            If sybClient.ExecuteSqlString(SQL.ToString(), DocNo) <> 0 Then
                Return False
            Else
                Return True
            End If


        Catch ex As Exception
            WriteLog("An exception occured while trying to Execute the Update SQL Statement IN ExecuteSync - " & ex.ToString())
            Return False
        End Try
    End Function

    Private Function additem() As String
        Dim lvReq As New SybrinMandate.Requirement
        Dim lvNewRule As New SybrinMandate.Rule
        Dim lvMandate As New SybrinMandate.Mandate
        Dim lvIdent As New Identifier

        ' A AND B OR A AND C OR B AND C OR A AND D OR B AND C OR B AND D  
        lvReq.Concatenator = manConcatenator.concatAnd
        lvReq.OccurenceCount = 1
        lvReq.OperatorValue = 1
        lvIdent.GroupID = "GUID"
        lvIdent.IdentityID = "GUID"
        lvIdent.IdentityName = "Group A"
        lvIdent.IdentityType = eIdentityTypes.Group
        lvIdent.OccurrenceCount = 1
        lvReq.Identifiers.Add(lvIdent)
        lvNewRule.Requirements.Add(lvReq)

        lvReq = New Requirement
        lvIdent = New Identifier
        lvReq.Concatenator = manConcatenator.concatAnd
        lvReq.OccurenceCount = 1
        lvReq.OperatorValue = 1
        lvIdent.GroupID = "GUID"
        lvIdent.IdentityID = "GUID"
        lvIdent.IdentityName = "Group B"
        lvIdent.IdentityType = eIdentityTypes.Group
        lvIdent.OccurrenceCount = 1
        lvReq.Identifiers.Add(lvIdent)
        lvNewRule.Requirements.Add(lvReq)

        lvMandate.Rules.Add(lvNewRule)

        Dim str As String
        str = lvMandate.ToEnglish

        Return str
    End Function

    Private Function SyncSIGMandateRule(ByVal MandateRules As ArrayList, ByVal AccountNo As String, ByVal SAGroups As ArrayList) As Boolean

        'CurrentMandate(0) = Mandate Rule Description
        'CurrentMandate(1) = SLCTCRT Description
        'CurrentMandate(2) = SLCTDIGNTOT - total Signatories to sign
        'CurrentMandate(3) = From Amount
        'CurrentMandate(4) = To Amount
        'CurrentMandate(5) = Date Captured Mandate 
        'CurrentMandate(6) = Mandate Expired Date
        'CurrentMandate(7) = Mandate date Updated
        'CurrentMandate(8) = Mandate Rule ID

        Try

            Dim CurrentMandate() As String
            Dim lvMandate As SybrinMandate.Mandate
            Dim ValueList As String = ""
            Dim SQL As String = ""
            Dim ManNo As Integer = 1

            If MandateRules.Count > 0 Then

                'Loop through the mandate rules that were found - extract their info.
                For MandateRule As Integer = 0 To MandateRules.Count - 1

                    CurrentMandate = Split(MandateRules(MandateRule).ToString(), ",")

                    lvMandate = New SybrinMandate.Mandate
                    lvMandate = ConvertMandateRule(CurrentMandate(4).ToString(), CurrentMandate(3).ToString(), CurrentMandate(0).ToString(), SAGroups)

                    If lvMandate.Rules.Count < 1 Then
                        WriteLog("Mandate could not be returned to SyncSIGMandateRule")
                        Return False
                    End If

                    'Validate the amount ranges passed from Source are correct.
                    If CurrentMandate(3).ToString() = "" Or CurrentMandate(3).ToString() = Nothing Then
                        CurrentMandate(3) = "0"
                    End If
                    If CurrentMandate(4).ToString() = "" Or CurrentMandate(4).ToString() = Nothing Or CurrentMandate(4).ToString() = "0" Then
                        CurrentMandate(4) = "1000000000"
                    End If

                    'Build the Value Statement
                    ValueList = ValueList & " ('" & AccountNo.ToString() & "' , 'SIGSALIVE' , '" & IIf(CurrentMandate(7).ToString() = "", CurrentMandate(5).ToString(), CurrentMandate(7).ToString()).ToString() _
                        & "' , '" & ManNo.ToString() & "' , '" & IIf(CurrentMandate(6).ToString() = "", "", CurrentMandate(6).ToString()).ToString() & "' , '0' , '" _
                        & lvMandate.ToXML().ToString() & "' , '" & lvMandate.ToEnglish().ToString() & "'),"

                    ManNo = ManNo + 1
                    'Move to Next Rule
                Next

                SQL = "INSERT INTO sybnedsigverlive.dbo.idmsMandate (AccountID, SystemID, ActiveFrom, MandateNo, ActiveTo, IsPendingChange, MandateInfo, MandateText) VALUES "

                'trim off trailing Comma
                If ValueList.EndsWith(",") Then ValueList = Microsoft.VisualBasic.Left(ValueList, ValueList.Length - 1)

                SQL = SQL & ValueList

                WriteLog("About to Insert Account Mandate Rules into Sybrin" & vbCrLf & SQL)

                'Execute the Insert
                If ExecuteSync(SQL, "") And ExecuteSync(Replace(Replace(SQL, "sybnedsigverlive", "sybnedsigver"), "SIGSALIVE", "SIGSACAPTURE"), "") Then
                    WriteLog("Account Mandate Rules have been copied to Sybrin")
                    Return True
                Else
                    WriteLog("Account Mandate Rules could not be copied to Sybrin")
                    Return False
                End If

            Else
                'each account must have at least 1 Mandate rule associated with it - something is wrong.
                WriteLog("No Mandate Found for this account")
                Return False
            End If

        Catch ex As Exception
            WriteLog("An unexpected erorr occured in SyncSIGMandateRule - " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function SyncSIGAccounts(ByVal Account As String, ByVal CIS As String) As Boolean
        Try

            Dim lvSQL As String
            Dim AccCheck As DataTable

            'Check if the account already exists in the Account table in Sybrin.

            lvSQL = "select Idx19 from Sybnedsigver.dbo.mandateaccounts where idx1  = '" & Account & "'"
            AccCheck = New DataTable()
            AccCheck = sybClient.GetDataTable(lvSQL)

            If Not AccCheck.Rows.Count > 0 Then

                'Add the Basic Info for the account that It needs.
                'The account will be set to A - Dormant so that processing on the account is suspended until such tim that the NEDMF is imported.
                lvSQL = "Insert Into Sybnedsigver.dbo.mandateaccounts (Idx1, Idx4, Idx8, Idx19, Inuse, UserID, Allocated) VALUES ('" & Account & "' , 'A' , '" & CIS & "' , 'SA' , '', '', '');"
                WriteLog("About To Add Account Information - SQL: " & lvSQL)
                Return ExecuteSync(lvSQL, "3")

                lvSQL = "Insert Into Sybnedsigver.dbo.MandateAccountsSACopy (Idx1, Idx4, Idx8, Idx19, Inuse, UserID, Allocated) VALUES ('" & Account & "' , 'A' , '" & CIS & "' , 'SA' , '', '', '')"
                WriteLog("About To Add Account Information - SQL: " & lvSQL)
                Return ExecuteSync(lvSQL, "3")

            Else
                'Account already imported via NEDMF
                WriteLog("The Account Already exists in the system, it will not be inserted again.")

                'reset Failed Flag if it is there
                If AccCheck(0)(0).ToString() = "SA-F" Then
                    lvSQL = "UPDATE Sybnedsigver.dbo.mandateaccounts SET IDX19 = 'SA' WHERE IDX19 = 'SA-F' AND Idx1 = '" & Account & "'"
                    If Not ExecuteSync(lvSQL, "3") Then
                        Return False
                    End If
                End If
                Return True
            End If

            AccCheck.Dispose()

        Catch ex As Exception
            WriteLog("An error occured in SyncSIGAccounts - " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function SyncSIGCards(ByVal SignatureCards As ArrayList, ByVal AccNo As String) As Boolean

        'Array Build
        'CurrentCard(0) - Account Number
        'CurrentCard(1) - Captured Date
        'CurrentCard(2) - Update Date

        Dim CurrentCard() As String
        Dim lvSQL As String
        Dim InsertValues As String

        Try

            If SignatureCards.Count > 0 Then

                lvSQL = "INSERT INTO SybNedSigver.dbo.MandateForms (Idx1, Idx2, Idx5, Idx7, Idx14, InUse, UserID, Allocated) VALUES"
                InsertValues = ""

                For Card As Integer = 0 To SignatureCards.Count - 1

                    'Break up the values into a String Array
                    CurrentCard = Split(SignatureCards(Card).ToString(), ",")

                    InsertValues = InsertValues & vbCrLf & " ('SA Migration Card' , '" & CurrentCard(0) & "' , '" & CDate(Replace(CurrentCard(1), "-", "/")).ToString("yyyy/MM/dd") _
                        & "' , '" & Replace(CurrentCard(1), "-", "/") & "' , '" & IIf(CurrentCard(2).Trim().Length < 1, "", Replace(CurrentCard(2), "-", "/")).ToString() & "' , '','',''),"

                Next

                If InsertValues.EndsWith(",") Then InsertValues = InsertValues.Substring(0, InsertValues.Length - 1)
                lvSQL = lvSQL & InsertValues

                WriteLog("About to Update Signature Card Information - SQL:" & lvSQL)

                Return ExecuteSync(lvSQL, "1")

            Else

                'No Signature Cards Passed
                WriteLog("No Signature Cards have been added fo this account")
                Return True 'not critical to have cards.

            End If

        Catch ex As Exception
            WriteLog("An Error has Occured in SyncSIGCards - " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function SyncMandateMembers(ByVal AccountNum As String, ByVal MandateMemberList As ArrayList, ByVal GroupCollection As ArrayList) As Boolean

        Dim lvSQL As String
        Dim MemberValues As String
        Dim lvSQLLive As String
        Dim MemberValueslive As String
        Dim CurrentMember() As String
        Dim MemCount As Integer = 0
        Dim MemberGuid As String
        Dim GUIDInString As String = ""
        Dim GUIDCollection As New ArrayList
        Dim GroupID As String
        Dim Indnos As DataTable
        Dim PageValues As String = ""
        Dim MemberPageInfo() As String
        Dim MemberIFNNo As String

        'CurrentMember(0) = IDNumber
        'CurrentMember(1) = Passport Number
        'CurrentMember(2) = name
        'CurrentMember(3) = CIS Num
        'CurrentMember(4) = STSCode
        'CurrentMember(5) = IFNDiskID
        'CurrentMember(6) = IFNDocID
        'CurrentMember(7) = PIFNDiskID
        'CurrentMember(8) = PIDNDocID
        'CurrentMember(9) = Capture Date
        'CurrentMember(10) = Update Date
        'CurrentMember(11) = Exprire Effect Date
        'CurrentMember(12) = Del received Date
        'CurrentMember(13) = MemberGroup

        Try

            If MandateMemberList.Count > 0 Then

                lvSQLLive = "INSERT INTO SybNedSigverlive.dbo.idmsMandateMember (AccountID,SystemID, GroupID, PersonID, ActiveFrom, ActiveTo, PendingUpdate, PendingDelete) VALUES "
                lvSQL = "INSERT INTO SybNedSigver.dbo.MandateMembers (Idx1, Idx2, Idx3, Idx4, Idx5, Idx6, Idx8, Idx11, Idx12, InUse, UserID, Allocated) VALUES "
                MemberValues = ""
                MemberValueslive = ""

                For Member As Integer = 0 To MandateMemberList.Count - 1

                    'member information to be extracted into a String array
                    CurrentMember = Split(MandateMemberList(Member).ToString(), ",")
                    MemCount = MemCount + 1
                    MemberGuid = System.Guid.NewGuid().ToString().Replace("-", "").ToUpper()

                    If CurrentMember(5) <> "" Then
                        'calculate the member IFN.
                        MemberIFNNo = (CInt(Math.Round(CInt(CurrentMember(5)) / 65536))).ToString() & "/" & (CInt(CurrentMember(5)) - (65536 * CInt(Math.Round(CInt(CurrentMember(5)) / 65536)))).ToString() & "-" & CurrentMember(6)
                        WriteLog("Member IFN has been Calculated: " & MemberIFNNo.ToString())
                    Else
                        'There is no IFN Number details for this member
                        MemberIFNNo = "IFN Missing"
                        WriteLog("There is No IFN details for this member.")
                    End If

                    GUIDCollection.Add(MemberGuid & "," & MemberIFNNo & "," & CurrentMember(9))

                    'Get the Guid for the Member Group
                    GroupID = GetGroupGuid(GroupCollection, CurrentMember(13).ToString().Trim())

                    If Not GroupID.Length > 0 Then
                        WriteLog("Group Id was retruned as: '" & GroupID & "' and cannot be processed, members for this account will not be added")
                        Return False
                    End If

                    'converts dates to be the correct format for idmsMandateMembersLive - only if date not null
                    If Not CurrentMember(9) = "" Then CurrentMember(9) = Microsoft.VisualBasic.Format(CDate(CurrentMember(9)), "yyyy/MM/dd")
                    If Not CurrentMember(10) = "" Then CurrentMember(10) = Microsoft.VisualBasic.Format(CDate(CurrentMember(10)), "yyyy/MM/dd")
                    If Not CurrentMember(11) = "" Then CurrentMember(11) = Microsoft.VisualBasic.Format(CDate(CurrentMember(11)), "yyyy/MM/dd")
                    If Not CurrentMember(12) = "" Then CurrentMember(12) = Microsoft.VisualBasic.Format(CDate(CurrentMember(12)), "yyyy/MM/dd")


                    MemberValues = MemberValues & "('" & MemberGuid & "' , '" & MemCount.ToString() & "' , '" & CurrentMember(2) & "' , '" & AccountNum & "' , '" _
                        & IIf(CurrentMember(0).Length > 0, CurrentMember(0), "").ToString() & "' , '" & CurrentMember(3) & "' , 'Signature' , 'Done' , '" _
                        & IIf(CurrentMember(1).Length > 0, CurrentMember(1), "").ToString() & "' , '' , '', ''),"

                    MemberValueslive = MemberValueslive & "('" & AccountNum & "' , 'SIGSALIVE' , '" & GroupID & "' , '" & MemberGuid & "' , '" _
                        & IIf(CurrentMember(10).Length > 0, Replace(CurrentMember(10), "-", "/"), Replace(CurrentMember(9), "-", "/")).ToString() & "' , '" _
                        & IIf(CurrentMember(11).Length > 0, Replace(CurrentMember(11), "-", "/"), "").ToString() & "' , "

                    CurrentMember(4) = Trim(CurrentMember(4))

                    If CurrentMember(4) = "A" Then
                        MemberValueslive = MemberValueslive & "'0' , '0'),"
                    ElseIf CurrentMember(4) = "I" Then
                        MemberValueslive = MemberValueslive & "'1' , '0'),"
                    ElseIf CurrentMember(4) = "D" Then
                        MemberValueslive = MemberValueslive & "'0' , '1'),"
                    Else
                        MemberValueslive = MemberValueslive & "'1' , '0'),"
                    End If

                Next

                If MemberValues.EndsWith(",") Then MemberValues = MemberValues.Substring(0, MemberValues.Length - 1)
                lvSQL = lvSQL & MemberValues

                If MemberValueslive.EndsWith(",") Then MemberValueslive = MemberValueslive.Substring(0, MemberValueslive.Length - 1)
                lvSQLLive = lvSQLLive & MemberValueslive


                'Start Inserting Members into Sybrin DB
                '----------------------------------------------------------------
                WriteLog("About to Add members Info - SQL: " & lvSQL)
                If ExecuteSync(lvSQL, "2") Then 'Update Mandate Members
                    WriteLog("Members added to Mandate Members!")

                    If ExecuteSync(Replace(lvSQL, "MandateMembers", "MandateMembersLive"), "6") Then 'Update members Live
                        WriteLog("Members added to Mandate Members Live!")

                        If ExecuteSync(lvSQLLive, "") And ExecuteSync(Replace(Replace(lvSQLLive, "SybNedSigverlive", "SybNedSigver"), "SIGSALIVE", "SIGSACAPTURE"), "") Then ' Update idmsMandate Member
                            WriteLog("Members added to idmsMandateMember")

                            'Add Page Info for members
                            '--------------------------------------------------------
                            ManageProgressBar(9, 15, "Sync Mandate Members - Adding Page Information", -1, -1)

                            'Gather page table Info
                            For lvGuid As Integer = 0 To GUIDCollection.Count - 1
                                'Create an IN statement with all the GUIDS that were added
                                MemberPageInfo = Split(GUIDCollection(lvGuid).ToString(), ",")
                                GUIDInString = GUIDInString & "'" & MemberPageInfo(0) & "',"
                            Next

                            If GUIDInString.EndsWith(",") Then GUIDInString = GUIDInString.Substring(0, GUIDInString.Length - 1)
                            lvSQL = "SELECT IndNo, Idx1 from Sybnedsigver.dbo.MandateMembers where Idx1 in (" & GUIDInString & ")"
                            WriteLog("Ready to get the IND Numbers - SQL: " & lvSQL)
                            Indnos = New DataTable()
                            Indnos = sybClient.GetDataTable(lvSQL)

                            If Indnos.Rows.Count > 0 Then

                                If Indnos.Rows.Count <> MemCount Then
                                    'This means that there were more rows added than we found IND's for
                                    'Some members were not added
                                    WriteLog("There are Missing Members, " & (MemCount - 1).ToString() & "Values were provided and only " & Indnos.Rows.Count.ToString() & " Ind Numbers were found")
                                    Return False
                                End If

                                WriteLog("Adding Page Records for Members")
                                lvSQLLive = "INSERT INTO Sybnedsigver.dbo.MandateMembersPge (IndNo,PageNo,VersionNo,PageClass,FileName,LocationClass,LocationPath,ScanDate,IndexDate,BytePointer,Multiside,Compressed,WHBoxNo,ByteLength,RearPointer,RearLength) values "
                                PageValues = Nothing

                                'add the IFN details to the values statement.
                                For Each indno As DataRow In Indnos.Rows
                                    PageValues = PageValues & "(" & indno("IndNo").ToString() & ",1 ,1 , 'IMG', '" & indno("Idx1").ToString() & "' , 'W' , "

                                    For number As Integer = 0 To GUIDCollection.Count - 1

                                        MemberPageInfo = Split(GUIDCollection(number).ToString(), ",")

                                        If MemberPageInfo(0) = indno("Idx1").ToString() Then

                                            PageValues = PageValues & "'" & MemberPageInfo(1) & "' , '" & MemberPageInfo(2) & "' , '" & MemberPageInfo(2) & "',0 ,0 ,0 ,'',0 ,0 ,0 ),"

                                        End If

                                    Next

                                Next

                                If PageValues.EndsWith(",") Then PageValues = PageValues.Substring(0, PageValues.Length - 1)
                                lvSQLLive = lvSQLLive & PageValues

                                WriteLog("About to Add Mandate Members Page Information - SQL: " & lvSQLLive)

                                If ExecuteSync(lvSQLLive, "") Then

                                    'Page information added - Do the same for the live table.
                                    ManageProgressBar(10, 15, "Sync Mandate Members - Adding Live Page Information", -1, -1)
                                    WriteLog("Mandate Members Page infromation has been Added")

                                    Indnos.Dispose()
                                    Indnos = New DataTable
                                    Indnos = sybClient.GetDataTable(Replace(lvSQL, "MandateMembers", "MandateMembersLive"))
                                    WriteLog("Attempt to retrieve INdNumbers - SQL: " & lvSQL)

                                    If Indnos.Rows.Count > 0 Then

                                        If Indnos.Rows.Count <> MemCount Then
                                            'This means that there were more rows added than we found IND's for
                                            'Some members were not added
                                            WriteLog("There are Missing Members, " & (MemCount - 1).ToString() & "Values were provided and only " & Indnos.Rows.Count.ToString() & " Ind Numbers were found")
                                            Return False
                                        End If

                                        lvSQLLive = "INSERT INTO Sybnedsigver.dbo.MandateMembersLivePge (IndNo,PageNo,VersionNo,PageClass,FileName,LocationClass,LocationPath,ScanDate,IndexDate,BytePointer,Multiside,Compressed,WHBoxNo,ByteLength,RearPointer,RearLength) values "
                                        PageValues = Nothing

                                        'Add the IFN number etc to the valuse statement.
                                        For Each indno As DataRow In Indnos.Rows

                                            PageValues = PageValues & "(" & indno("IndNo").ToString() & ",1 ,1 , 'IMG', '" & indno("Idx1").ToString() & "' , 'W' , "

                                            For number As Integer = 0 To GUIDCollection.Count - 1

                                                MemberPageInfo = Split(GUIDCollection(number).ToString(), ",")

                                                If MemberPageInfo(0) = indno("Idx1").ToString() Then

                                                    PageValues = PageValues & "'" & MemberPageInfo(1) & "' , '" & MemberPageInfo(2) & "' , '" & MemberPageInfo(2) & "',0 ,0 ,0 ,'',0 ,0 ,0 ),"

                                                End If

                                            Next
                                        Next

                                        If PageValues.EndsWith(",") Then PageValues = PageValues.Substring(0, PageValues.Length - 1)
                                        lvSQLLive = lvSQLLive & PageValues

                                        WriteLog("About to Add Mandate Members Live Page Information - SQL: " & lvSQLLive)

                                        If ExecuteSync(lvSQLLive, "") Then

                                            WriteLog("Page information has been added to Mandate Members Live")
                                            Indnos.Dispose()
                                            Return True
                                            'DONE ENDPOINT

                                        Else
                                            WriteLog("Could not add the Page information into mandate Members Live")
                                            Return False
                                        End If

                                    Else
                                        WriteLog("Could not Retrieve IndNumbers from MandateMembersLive")
                                        Return False
                                    End If

                                Else
                                    WriteLog("Member Page inforamtion could not be added")
                                    Return False
                                End If


                            Else
                                WriteLog("Not Able to Retrieve IndNumbers")
                                Return False

                            End If

                        Else
                            WriteLog("Query could not be Executed into idmsMandateMember")
                            Return False
                        End If
                    Else
                        WriteLog("Query could not be Executed into MandateMembersLive")
                        Return False
                    End If
                Else
                    WriteLog("Query could not be Executed into MandateMembers")
                    Return False
                End If


            Else
                WriteLog("No Members Will be added for this account")
                Return True  'not critical for the account to have members as this could be a new account recently opened
            End If

        Catch ex As Exception
            WriteLog("An unexpected error occured in SYNCMandateMembers - " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function ClearAccountData(ByVal AccountNumber As String) As Boolean
        'Works with Specific Account Numbers - Delete one account at a time.

        Dim SQL As String

        Try

            WriteLog("Ready to Clear Account Legacy Data for Account NUmber: " & AccountNumber)


            'Clear the existing data out of Mandate Forms
            SQL = "DELETE FROM SybNedSigver.dbo.MandateForms WHERE Idx2 = '" & AccountNumber & "'"
            WriteLog("About to Clear existing data from Mandate Forms" & vbCrLf & SQL)

            If ExecuteSync(SQL, "1") = False Then
                'could not clear old data - Break Out
                WriteLog("Failed to Clear Old Data")
                Return False
            End If

            'Clear existing Data out of SybNedSigverlive.dbo.idmsMandateMember
            SQL = "DELETE FROM SybNedSigverLive.dbo.idmsMandateMember WHERE AccountID = '" & AccountNumber & "'"
            WriteLog("About to Clear Data from idmsMandateMember in SigverLive and Sigver" & vbCrLf & SQL)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "SybNedSigverLive", "SybNedSigver"), "") = False Then
                'could not clear data
                WriteLog("Failed to Clear Old Data from idmsMandateMember")
                Return False
            End If

            'Delete old Data from SybNedSigver.dbo.MandateMembersPGE and SybNedSigver.dbo.MandateMemberslivePge
            SQL = "DELETE FROM SybNedSigver.dbo.MandateMembersPge where Indno In ( Select Indno from SybNedSigver.dbo.MandateMembers where Idx4 = '" & AccountNumber & "')"
            WriteLog("About the clear Data from MandateMembersPge and MandateMembersLIvePge" & vbCrLf & SQL)

            'We do both MandateMembers and MandateMemberslive
            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "MandateMembers", "MandateMembersLive"), "") = False Then
                'could not clear data
                WriteLog("Failed to Clear Old Data from Member Page Tables")
                Return False
            End If

            'Delete Old Data from SybNedSigver.dbo.MandateMembers and SybNedSigver.dbo.MandateMembersLIve
            SQL = "DELETE FROM SybNedSigver.dbo.MandateMembers WHERE Idx4 = '" & AccountNumber & "'"
            WriteLog("About to Clear Data from MandateMembers and MandateMembersLive" & vbCrLf & SQL)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "MandateMembers", "MandateMembersLive"), "") = False Then
                'could not Clear Data
                WriteLog("Failed to Clear Data from MandateMembers and MandateMembersLive")
                Return False
            End If

            'Delete Old Data from idmsMandate
            SQL = "DELETE FROM SybNedSigverlive.dbo.idmsMandate WHERE AccountID = '" & AccountNumber & "'"
            WriteLog("About to Delete From idmsMandate IN SigverLive and Sigver" & vbCrLf & SQL)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "SybNedSigverlive", "SybNedSigver"), "") = False Then
                WriteLog("Failed to Clear old data from idmsMandate")
                Return False
            End If

            ' if reach this point and not return then all deletions were successfull.
            WriteLog("Legacy Data for Account Number " & AccountNumber & "has been cleared successfully")
            Return True

        Catch ex As Exception
            WriteLog("Error occured in Clear Account Data: " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function ClearData() As Boolean
        Dim SQL As String

        Try

            WriteLog("Ready to Clear all Savings Accounts from the System")


            'Clear the existing data out of Mandate Forms
            SQL = "DELETE FROM SybNedSigver.dbo.MandateForms WHERE Idx2 LIKE '2%'"
            WriteLog("About to Clear existing data from Mandate Forms" & vbCrLf & SQL)

            If ExecuteSync(SQL, "1") = False Then
                'could not clear old data - Break Out
                WriteLog("Failed to Clear Old Data from Mandate Forms")
                Return False
            End If

            ''Clear existing Data out of SybNedSigverlive.dbo.idmsMandateMember
            'SQL = "DELETE FROM SybNedSigverLive.dbo.idmsMandateMember WHERE AccountID LIKE '2%'"
            'WriteLog("About to Clear Data from idmsMandateMember in SigverLive and Sigver" & vbCrLf & SQL)

            'If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "SybNedSigverLive", "SybNedSigver"), "") = False Then
            '    'could not clear data
            '    WriteLog("Failed to Clear Old Data from idmsMandateMember")
            '    Return False
            'End If

            'Delete old Data from SybNedSigver.dbo.MandateMembersPGE and SybNedSigver.dbo.MandateMemberslivePge
            SQL = "DELETE FROM SybNedSigver.dbo.MandateMembersPge where Indno In ( Select Indno from SybNedSigver.dbo.MandateMembers where Idx4 LIKE '2%')"
            WriteLog("About the clear Data from MandateMembersPge and MandateMembersLIvePge" & vbCrLf & SQL)

            'We do both MandateMembers and MandateMemberslive
            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "MandateMembers", "MandateMembersLive"), "") = False Then
                'could not clear data
                WriteLog("Failed to Clear Old Data from Member Page Tables")
                Return False
            End If

            'Delete Old Data from SybNedSigver.dbo.MandateMembers and SybNedSigver.dbo.MandateMembersLIve
            SQL = "DELETE FROM SybNedSigver.dbo.MandateMembers WHERE Idx4 LIKE '2%'"
            WriteLog("About to Clear Data from MandateMembers and MandateMembersLive" & vbCrLf & SQL)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "MandateMembers", "MandateMembersLive"), "") = False Then
                'could not Clear Data
                WriteLog("Failed to Clear Data from MandateMembers and MandateMembersLive")
                Return False
            End If

            'Delete Old Data from idmsMandate
            SQL = "DELETE FROM SybNedSigverlive.dbo.idmsMandate WHERE AccountID LIKE '2%'"
            WriteLog("About to Delete From idmsMandate IN SigverLive and Sigver" & vbCrLf & SQL)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(SQL, "SybNedSigverlive", "SybNedSigver"), "") = False Then
                WriteLog("Failed to Clear old data from idmsMandate")
                Return False
            End If

            ' if reach this point and not return then all deletions were successfull.
            WriteLog("Existing Data for All Savings Accounts have been cleared successfully")
            Return True

        Catch ex As Exception
            WriteLog("Error occured in Clear Account Data: " & ex.ToString())
            Return False
        End Try
    End Function

    Private Function AccountSyncFailure(ByVal AccNo As String) As Boolean
        'function will be called if an account has failed to SYNC to Sybrin.

        Dim SQL As String

        Try

            WriteLog("Account Number " & AccNo & " has failed to SYNC To Sybrin")

            'update the account so that we can re-process it Later
            SQL = "UPDATE SybNedSigVer.dbo.MandateAccounts SET Idx19 = 'SA-F' WHERE Idx1 = '" & AccNo & "'"

            If ExecuteSync(SQL, "3") = False Then
                WriteLog("Unable to Update Failed Account for Later Identification")
                Return False

            Else
                WriteLog("Account has been flagged as having Failed in SYNC, Identify with Idx19 = SA-F")
            End If

            'anything else ?

            Return True

        Catch ex As Exception
            WriteLog("An error occured in AccountSyncFailure: " & ex.ToString())
            Return False
        End Try

    End Function

    Private Function AddSAGroups() As ArrayList

        Dim SAGroupsList As ArrayList = New ArrayList
        Dim SQL As String
        Dim GroupTable As DataTable
        Dim ArrayItem As String

        Try

            'Get the Current Sigver SA Groups
            SQL = "Select Name, GroupID from SybNedSigverLive.dbo.idmsMandategroup where systemid = 'SIGSALIVE' ORDER BY Name"

            WriteLog("About to check for SA Groups in Sybrin" & vbCrLf & SQL)

            GroupTable = New DataTable()
            GroupTable = sybClient.GetDataTable(SQL)

            If GroupTable.Rows.Count >= 26 Then 'A - Z GROUPS ARE ALREADY IN

                'Groups are already there, load them into the Arraylist and return the list to be used
                For Each GrpRow As DataRow In GroupTable.Rows
                    ArrayItem = Replace(Replace(GrpRow("Name").ToString(), "Group", ""), " ", "") & Trim(GrpRow("GroupID").ToString())
                    SAGroupsList.Add(ArrayItem)
                Next

            Else

                'Delete the current SA Groups out of Sybrin 
                SQL = "DELETE FROM SybNedSigVerLive.dbo.idmsMandateGroup WHERE SystemID = 'SIGSALIVE'"

                WriteLog("About to Delete Sigver SA Groups from Sybrin" & vbCrLf & SQL)

                If Not ExecuteSync(SQL, "") And Not ExecuteSync(Replace(Replace(SQL, "SybNedSigVerLive", "SybNedSigVer"), "SIGSALIVE", "SIGSACAPTURE"), "") Then
                    WriteLog("Failed to Delete old SA Groups from Sybrin")
                    Return SAGroupsList
                Else

                    WriteLog("SA Groups and Mandates Deleted, About to Add new Groups to group array")

                    SAGroupsList.Add("A" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("B" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("C" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("D" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("E" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("F" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("G" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("H" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("I" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("J" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("K" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("L" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("M" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("N" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("O" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("P" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("Q" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("R" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("S" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("U" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("T" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("V" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("W" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("X" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("Y" & Replace(System.Guid.NewGuid().ToString(), "-", ""))
                    SAGroupsList.Add("Z" & Replace(System.Guid.NewGuid().ToString(), "-", ""))

                    SQL = "INSERT INTO SybNedSigVerLive.dbo.idmsMandateGroup (GroupID, SystemID, Name) Values "
                    WriteLog("Add group array to SQL insert")

                    For GroupItem As Integer = 0 To SAGroupsList.Count - 1

                        SQL = SQL & "('" & Microsoft.VisualBasic.Right(SAGroupsList(GroupItem).ToString(), SAGroupsList(GroupItem).ToString().Length - 1).ToString() & "' , 'SIGSALIVE' , 'Group " & Microsoft.VisualBasic.Left(SAGroupsList(GroupItem).ToString(), 1).ToString() & "'),"

                    Next

                    'Trim the last comma
                    If Microsoft.VisualBasic.Right(SQL, 1) = "," Then SQL = Microsoft.VisualBasic.Left(SQL, SQL.Length - 1)

                    WriteLog("Adding Sigver SA Base Groups" & vbCrLf & SQL)

                    If ExecuteSync(SQL, "") = True And ExecuteSync(Replace(Replace(SQL, "SybNedSigVerLive", "SybNedSigVer"), "SIGSALIVE", "SIGSACAPTURE"), "") Then
                        WriteLog("SA Base Groups have been added")
                    Else
                        WriteLog("Could not Add SA Base Groups")
                    End If

                End If
            End If

            Return SAGroupsList

        Catch ex As Exception
            WriteLog("An error occured when attempting to Delete SA Groups currently in Sybrin" & vbCrLf & ex.ToString())
            Return SAGroupsList
        End Try
    End Function

    Private Function DeleteSATemplates() As Boolean
        Try
            Dim SQL As String

            SQL = "DELETE FROM SybNedSigVerLive.dbo.idmsMandate WHERE SystemID = 'SIGSALIVE' AND AccountID = ''"

            'Delete Sigver SA Templates from Sybrin.
            WriteLog("About to Delete Old Sigver SA Mandate Templates from Sybrin" & vbCrLf & Sql)

            If ExecuteSync(SQL, "") = False Or ExecuteSync(Replace(Replace(SQL, "SybNedSigVerLive", "SybNedSigVer"), "SIGSALIVE", "SIGSACAPTURE"), "") = False Then
                WriteLog("Failed to Delete old SA Templates from Sybrin")
                Return False
            Else
                WriteLog("Sigver SA Templates Deleted From Sybrin")
                Return True
            End If

        Catch ex As Exception
            WriteLog("An error occured in DeleteSATemplates" & vbCrLf & ex.ToString())
            Return False
        End Try
    End Function

    Private Function GetGroupGuid(ByVal GroupLst As ArrayList, ByVal GrpChar As String) As String

        Try
            'Function is used to get the Guid of a specific Group Character
            For Guid As Integer = 0 To GroupLst.Count - 1

                If Microsoft.VisualBasic.Left(GroupLst(Guid).ToString(), 1) = GrpChar Then
                    Return Microsoft.VisualBasic.Right(GroupLst(Guid).ToString(), GroupLst(Guid).ToString().Length - 1).ToUpper()
                Else
                    'do nothing
                End If

            Next

            Return ""

        Catch ex As Exception
            WriteLog("An erorr has occured in GetGroupGuid" & vbCrLf & ex.ToString())
            Return ""
        End Try

    End Function

    Private Sub BtnCopyMandateTemplates_Click(sender As Object, e As EventArgs) Handles BtnCopyMandateTemplates.Click

        Dim ODBCcon As OdbcConnection
        Dim RetVal As Integer
        Dim SourceCommand As OdbcCommand
        Dim OdbcDataAdap As OdbcDataAdapter
        Dim MandateTemplates As DataTable
        Dim lvSQL As String
        Dim MandateCount As Integer = 0
        Dim CopyCount As Integer = 0
        Dim lvMandate As New SybrinMandate.Mandate
        Dim InsertMandateValues As String = ""
        Dim GroupList As ArrayList = New ArrayList


        Try

            'check if we can start
            If CheckStart() = True Then

                ManageProgressBar(1, 2, "Connecting to Source", 1, 3)

                'Create a Mandate Template convesrtion log in the same place as teh other as per the user.
                txtLogPath.Text = Replace(txtLogPath.Text, ".", "-TemplateConversion.")

                WriteLog("Attempting to connect to the Source DB")

                'connect to Source
                ODBCcon = New OdbcConnection(txtSourceConn.Text)
                ODBCcon.Open()

                ManageProgressBar(2, 2, "Connecting to Sybrin", -1, -1)
                WriteLog("Attempting to connect to Sybrin")

                'Connect to Sybrin
                If sybClient Is Nothing Then sybClient = New Sybrin.Client.Client
                If Not sybClient.LoggedOn Then
                    RetVal = sybClient.Logon(Sybrin.Common.SybrinModule.Scheduler, "Wikus", "123", txtClientConn.Text, CInt(txtPortN.Text))
                    If RetVal = 0 Then
                        WriteLog("Connected to Sybrin Client")
                    Else
                        WriteLog("Could not Connect to Sybrin")
                    End If
                Else
                    WriteLog("Sybrin Client is Logged On")
                End If

                'Reset the Sybrin SA Groups.
                GroupList = AddSAGroups()
                If Not GroupList.Count > 0 Then
                    Return
                End If

                'Delete old Templates out.
                If Not DeleteSATemplates() = True Then
                    Return
                End If

                'Get the Templates currently being used by Sigver SA.

                lvSQL = "SELECT SV09_MNDT_RULE_ID , SV09_MND_RULE_DESC , SV09_SLCT_CRT_DESC , SV09_SLCT_SIGN_TOT FROM NSVD99.SV09_MNDT_RULE WHERE SV09_MNDT_RULE_ID <> 664"

                ManageProgressBar(1, 3, "Get Templates from Source DB2", 2, 3)
                WriteLog("Ready to Retrieve the Templates from the Source DB" & vbCrLf & lvSQL)

                SourceCommand = New OdbcCommand(lvSQL, ODBCcon)
                OdbcDataAdap = New OdbcDataAdapter(SourceCommand)
                MandateTemplates = New DataTable()
                OdbcDataAdap.Fill(MandateTemplates)

                'check if there were any results returned
                If Not MandateTemplates.Rows.Count > 0 Then
                    WriteLog("No Templates have been returned to be convereted to Sybrin")
                Else

                    WriteLog("Templates have been found and will be processed individually")

                    'Loop through and map each Template into Sybrin
                    For Each Mandate As DataRow In MandateTemplates.Rows
                        ManageProgressBar(2, 3, "Process Template", -1, -1)

                        lvMandate = ConvertMandateRule("", "", Mandate("SV09_MND_RULE_DESC").ToString(), GroupList)
                        If lvMandate.Rules.Count < 1 Then
                            WriteLog("Unable to convert Mandate Rule, conversion will stop.")
                            Return
                        End If

                        ManageProgressBar(3, 3, "Process Template", -1, -1)

                        MandateCount = MandateCount + 1
                        CopyCount = CopyCount + 1

                        'Ready to Insert the New Mandate Details Into Sybrin
                        InsertMandateValues = InsertMandateValues & _
                            "('' , 'SIGSALIVE' , '2013/08/20' , '" & MandateCount.ToString() & "' , '' , '0' , '" & _
                            lvMandate.ToXML.ToString() & "' , '" & lvMandate.ToEnglish().ToString() & "'),"

                        'Insert the rules 15 at a time.
                        If CopyCount = 15 Then

                            CopyCount = 0

                            'Cut the Last comma off
                            If Microsoft.VisualBasic.Right(InsertMandateValues, 1) = "," Then InsertMandateValues = Microsoft.VisualBasic.Left(InsertMandateValues, InsertMandateValues.Length - 1)

                            lvSQL = "Insert Into sybnedsigverlive.dbo.idmsmandate (AccountID , SystemID , ActiveFrom , MandateNo , ActiveTo , IsPendingChange , MandateInfo , MandateText) VALUES "
                            lvSQL = lvSQL & InsertMandateValues

                            WriteLog("About to Insert Mandate Templates into Sybrin DB" & vbCrLf & lvSQL)

                            If ExecuteSync(lvSQL, "") And ExecuteSync(Replace(Replace(lvSQL, "sybnedsigverlive", "SybNedSigVer"), "SIGSALIVE", "SIGSACAPTURE"), "") Then
                                WriteLog("Mandate Templates have been migarted to Sybrin")
                            Else
                                WriteLog("Failed to Migrate Mandate Templates to Sybrin")
                            End If

                            InsertMandateValues = ""

                        End If

                        'MOVE TO NEXT Mandate Rule in DB2
                        lvMandate = New SybrinMandate.Mandate
                    Next

                    'insert whatever is left
                    If CopyCount > 0 Then
                        CopyCount = 0

                        'Cut the Last comma off
                        If Microsoft.VisualBasic.Right(InsertMandateValues, 1) = "," Then InsertMandateValues = Microsoft.VisualBasic.Left(InsertMandateValues, InsertMandateValues.Length - 1)

                        lvSQL = "Insert Into sybnedsigverlive.dbo.idmsmandate (AccountID , SystemID , ActiveFrom , MandateNo , ActiveTo , IsPendingChange , MandateInfo , MandateText) VALUES "
                        lvSQL = lvSQL & InsertMandateValues

                        WriteLog("About to Insert Mandate Templates into Sybrin DB" & vbCrLf & lvSQL)

                        If ExecuteSync(lvSQL, "") And ExecuteSync(Replace(Replace(lvSQL, "sybnedsigverlive", "SybNedSigVer"), "SIGSALIVE", "SIGSACAPTURE"), "") Then
                            WriteLog("Mandate Templates have been migarted to Sybrin")
                        Else
                            WriteLog("Failed to Migrate Mandate Templates to Sybrin")
                        End If
                    End If

                End If

                MandateTemplates.Dispose()

                WriteLog("Mandate Rule conversion Completed Successfully")
                WriteLog(MandateCount.ToString() & " Mandates have been Merged to Sybrin")
                ManageProgressBar(3, 3, MandateCount.ToString() & " Mandates have been Merged to Sybrin", 3, 3)
                MessageBox.Show(MandateCount.ToString() & " Mandates have been Merged to Sybrin")

            Else

                WriteLog("CheckStart Failed")
                txtLogPath.Text = Replace(txtLogPath.Text, "-TemplateConversion.", ".")

            End If

            'finally
            FormReset()

            'Change the Log Back
            txtLogPath.Text = Replace(txtLogPath.Text, "-TemplateConversion.", ".")

        Catch ex As Exception
            WriteLog("An error occured While trying to copy the Mandate Templates to Sybrin" & vbCrLf & ex.ToString())
            FormReset()
            'Change the Log Back
            txtLogPath.Text = Replace(txtLogPath.Text, "-TemplateConversion.", ".")
            Return
        End Try

    End Sub


    Private Sub btnFailersReSync_Click(sender As Object, e As EventArgs) Handles btnFailersReSync.Click
        'The user would click this to re-Syncronize accounts that failed to be moved accross to Sybrin.

        Dim lvSQL As String
        Dim ReturnVal As Integer
        Dim FailedAccDT As DataTable
        Dim ReSyncWhere As String

        Try

            If CheckStart() = True Then

                'Connect to Sybrin
                If sybClient Is Nothing Then sybClient = New Sybrin.Client.Client
                If Not sybClient.LoggedOn Then
                    ReturnVal = sybClient.Logon(Sybrin.Common.SybrinModule.Scheduler, "Wikus", "123", txtClientConn.Text, CInt(txtPortN.Text))
                    If ReturnVal = 0 Then
                        WriteLog("Connected to Sybrin Client")
                    Else
                        WriteLog("Could not Connect to Sybrin")
                    End If
                Else
                    WriteLog("Sybrin Client is Logged On")
                End If

                'Identify the accounts that previously failed to be moved.
                lvSQL = "Select Idx1 from SybNedSigVer.dbo.MandateAccounts WHERE Idx19 = 'SA-F'"

                WriteLog("Identify the accounts that previously failed to be moved to Sybrin" & vbCrLf & "SQL: " & lvSQL)

                FailedAccDT = New DataTable()
                FailedAccDT = sybClient.GetDataTable(lvSQL)

                If FailedAccDT.Rows.Count > 0 Then

                    WriteLog("Failed Accounts have been found, attempt to Re- Sync")

                    'Build the String that will be used to find the accounts in DB2.
                    ReSyncWhere = "WHERE "
                    For Each Account As DataRow In FailedAccDT.Rows

                        ReSyncWhere = ReSyncWhere & "SV00_AC_NUM Like '%" & Account("Idx1").ToString() & "' OR "

                    Next

                    'strip the trailing OR.
                    If Microsoft.VisualBasic.Right(ReSyncWhere, 2) = "OR" Then ReSyncWhere = Microsoft.VisualBasic.Left(ReSyncWhere, ReSyncWhere.Length - 2).ToString()
                    If Microsoft.VisualBasic.Right(ReSyncWhere, 3) = "OR " Then ReSyncWhere = Microsoft.VisualBasic.Left(ReSyncWhere, ReSyncWhere.Length - 3).ToString()
                    txtSQLWhere.Text = ReSyncWhere.ToString()

                    btnInit.Enabled = True 'you would think calling it from code will bypass enabled, wtf.
                    btnInit.PerformClick()
                    btnInit.Enabled = False


                Else
                    WriteLog("No Accounts found that failed to SYNC")

                End If

                FailedAccDT.Dispose()
            End If

        Catch ex As Exception
            WriteLog("An error occured while trying to Re-Sync Failed Cards: " & ex.ToString())
            FormReset()
            Return
        End Try


    End Sub

    Private Function ConvertMandateRule(ByVal ToAmount As String, ByVal FromAmount As String, ByVal RuleDescription As String, ByVal GroupList As ArrayList) As SybrinMandate.Mandate

        Try

            Dim lvReq As SybrinMandate.Requirement
            Dim lvNewRule As SybrinMandate.Rule
            Dim lvMandate As New SybrinMandate.Mandate
            Dim lvIdent As Identifier
            Dim lvCondition As SybrinMandate.Condition

            Dim CurGuid As String
            Dim ManAlreadyCounted As ArrayList = New ArrayList
            Dim RequiredGroups() As String
            Dim Requirementlist() As String
            Dim SimpleCount As Integer = 0

            'check passed variables accuracy
            If FromAmount = "" Or FromAmount = Nothing Then
                'FromAmount = "0"
                FromAmount = "<#Value1#>"
            End If
            If ToAmount = "" Or ToAmount = Nothing Or ToAmount = "0" Then
                'ToAmount = "1000000000"
                ToAmount = "<#Value2#>"
            End If

            WriteLog("Current SA Rule to be converted: " & RuleDescription)

            WriteLog("Populate the Condition Values")

            'Add the Condition default for SA
            'lvCondition = New SybrinMandate.Condition

            'lvCondition.Concatenator = manConcatenator.concatAnd
            'lvCondition.Depth = 1
            'lvCondition.Operator = manOperator.opBetween
            'lvCondition.Values.Add(FromAmount)
            'lvCondition.Values.Add(ToAmount)


            If Not RuleDescription.Contains("OR") Then
                'There is a Single Requirement

                If Not RuleDescription.Contains("AND") Then
                    '-------------------------------------------
                    'One Group Listed and One Member
                    '-------------------------------------------
                    lvNewRule = New SybrinMandate.Rule

                    lvReq = New SybrinMandate.Requirement
                    lvReq.Concatenator = manConcatenator.concatAnd
                    lvReq.OccurenceCount = 1
                    lvReq.OperatorValue = 1

                    'get the Guid associated with thsi group letter
                    CurGuid = GetGroupGuid(GroupList, Trim(RuleDescription))

                    If Not CurGuid <> "" Then
                        WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                        Return Nothing
                    Else
                        'Found the Guid for this Group
                        lvIdent = New SybrinMandate.Identifier
                        lvIdent.GroupID = CurGuid
                        lvIdent.IdentityID = CurGuid
                        lvIdent.IdentityName = "Group " & Trim(RuleDescription)
                        lvIdent.IdentityType = eIdentityTypes.Group
                        lvIdent.OccurrenceCount = 1

                        lvReq.Identifiers.Add(lvIdent)
                        lvNewRule.Requirements.Add(lvReq)

                        'reset them for each Rule that is finalized
                        lvMandate = New SybrinMandate.Mandate

                        lvCondition = New SybrinMandate.Condition
                        lvCondition.FieldNo = "6"
                        lvCondition.Source = "Amount"
                        lvCondition.CompareAsType = eCompareTypes.ctNumber
                        lvCondition.Concatenator = manConcatenator.concatAnd
                        lvCondition.Depth = 1
                        lvCondition.Operator = manOperator.opGreaterThanOrEqual
                        lvCondition.Values.Add(FromAmount)

                        lvNewRule.Conditions.Add(lvCondition)

                        lvCondition = New SybrinMandate.Condition
                        lvCondition.FieldNo = "6"
                        lvCondition.Source = "Amount"
                        lvCondition.CompareAsType = eCompareTypes.ctNumber
                        lvCondition.Concatenator = manConcatenator.concatAnd
                        lvCondition.Depth = 1
                        lvCondition.Operator = manOperator.opLessThanOrEqual
                        lvCondition.Values.Add(ToAmount)

                        lvNewRule.Conditions.Add(lvCondition)
                        lvMandate.Rules.Add(lvNewRule)

                    End If

                Else

                    'Multiple Groups Sign Together One Rule Set
                    RequiredGroups = Split(Replace(RuleDescription, " ", ""), "AND")

                    lvNewRule = New SybrinMandate.Rule


                    For GroupCode As Integer = 0 To RequiredGroups.Count - 1
                        SimpleCount = 0

                        'get the Guid associated with this group letter
                        CurGuid = GetGroupGuid(GroupList, RequiredGroups(GroupCode).ToString())

                        If Not CurGuid <> "" Then
                            WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                            Return Nothing
                        Else

                            'check how many people from this group need to authorise
                            For Each cha As Char In Replace(Replace(RuleDescription, " ", ""), "AND", "")
                                If cha = RequiredGroups(GroupCode).ToString() Then
                                    SimpleCount = SimpleCount + 1
                                End If
                            Next

                            If Not ManAlreadyCounted.Contains(CurGuid) Then

                                lvReq = New SybrinMandate.Requirement
                                lvReq.OccurenceCount = 1
                                lvReq.Concatenator = manConcatenator.concatAnd

                                'Add to indetifier
                                lvIdent = New SybrinMandate.Identifier
                                lvIdent.GroupID = CurGuid
                                lvIdent.IdentityID = CurGuid
                                lvIdent.IdentityName = "Group " & RequiredGroups(GroupCode).ToString()
                                lvIdent.IdentityType = eIdentityTypes.Group
                                lvIdent.OccurrenceCount = 1
                                lvReq.OperatorValue = CType(SimpleCount, Short)

                                'already counted this Group
                                ManAlreadyCounted.Add(CurGuid)

                                lvReq.Identifiers.Add(lvIdent)
                                lvNewRule.Requirements.Add(lvReq)

                            End If

                        End If

                    Next

                    ManAlreadyCounted.Clear()
                    'reset them for each Rule that is finalized
                    lvMandate = New SybrinMandate.Mandate

                    lvCondition = New SybrinMandate.Condition
                    lvCondition.FieldNo = "6"
                    lvCondition.Source = "Amount"
                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                    lvCondition.Concatenator = manConcatenator.concatAnd
                    lvCondition.Depth = 1
                    lvCondition.Operator = manOperator.opGreaterThanOrEqual
                    lvCondition.Values.Add(FromAmount)

                    lvNewRule.Conditions.Add(lvCondition)

                    lvCondition = New SybrinMandate.Condition
                    lvCondition.FieldNo = "6"
                    lvCondition.Source = "Amount"
                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                    lvCondition.Concatenator = manConcatenator.concatAnd
                    lvCondition.Depth = 1
                    lvCondition.Operator = manOperator.opLessThanOrEqual
                    lvCondition.Values.Add(ToAmount)

                    lvNewRule.Conditions.Add(lvCondition)
                    lvMandate.Rules.Add(lvNewRule)

                End If

            Else

                'check if there are 2x single group requirements in one Rule
                If RuleDescription.Contains("AND") = False And RuleDescription.Contains("OR") = True Then

                    'There are a series of single groups to sign
                    lvNewRule = New SybrinMandate.Rule

                    lvReq = New SybrinMandate.Requirement
                    lvReq.Concatenator = manConcatenator.concatAnd

                    lvReq.OccurenceCount = 1

                    RequiredGroups = Split(Replace(RuleDescription, " ", ""), "OR")

                    For GroupCode As Integer = 0 To RequiredGroups.Count - 1
                        SimpleCount = 0

                        'get the Guid associated with this group letter
                        CurGuid = GetGroupGuid(GroupList, RequiredGroups(GroupCode).ToString())

                        If Not CurGuid <> "" Then
                            WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                            Return Nothing
                        Else

                            If Not ManAlreadyCounted.Contains(RequiredGroups(GroupCode).ToString()) Then

                                ''check how many people from this group need to authorise
                                'For Each cha As Char In Replace(Replace(RuleDescription, " ", ""), "OR", "")
                                '    If cha = RequiredGroups(GroupCode).ToString() Then
                                '        SimpleCount = SimpleCount + 1
                                '    End If
                                'Next

                                'Found the Guid for this Group
                                lvIdent = New SybrinMandate.Identifier
                                lvIdent.GroupID = CurGuid
                                lvIdent.IdentityID = CurGuid
                                lvIdent.IdentityName = "Group " & RequiredGroups(GroupCode).ToString()
                                lvIdent.IdentityType = eIdentityTypes.Group
                                lvIdent.OccurrenceCount = SimpleCount
                                lvReq.OperatorValue = 1


                                lvReq.Identifiers.Add(lvIdent)
                                ManAlreadyCounted.Add(RequiredGroups(GroupCode).ToString())

                            End If

                        End If

                    Next

                    lvNewRule.Requirements.Add(lvReq)

                    'reset them for each Rule that is finalized
                    lvMandate = New SybrinMandate.Mandate

                    lvCondition = New SybrinMandate.Condition
                    lvCondition.FieldNo = "6"
                    lvCondition.Source = "Amount"
                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                    lvCondition.Concatenator = manConcatenator.concatAnd
                    lvCondition.Depth = 1
                    lvCondition.Operator = manOperator.opGreaterThanOrEqual
                    lvCondition.Values.Add(FromAmount)

                    lvNewRule.Conditions.Add(lvCondition)

                    lvCondition = New SybrinMandate.Condition
                    lvCondition.FieldNo = "6"
                    lvCondition.Source = "Amount"
                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                    lvCondition.Concatenator = manConcatenator.concatAnd
                    lvCondition.Depth = 1
                    lvCondition.Operator = manOperator.opLessThanOrEqual
                    lvCondition.Values.Add(ToAmount)

                    lvNewRule.Conditions.Add(lvCondition)
                    lvMandate.Rules.Add(lvNewRule)
                Else

                    'There is more than one requirement - there are all part of a Single Rule.
                    lvNewRule = New SybrinMandate.Rule
                    Requirementlist = Split(RuleDescription, "OR")

                    'LOOP the requirements

                    For Requirement As Integer = 0 To Requirementlist.Count - 1
                        lvNewRule = New SybrinMandate.Rule

                        'Do for each requirement same Logic as when there was only One Requirement.

                        If Not Requirementlist(Requirement).ToString().Contains("OR") Then
                            'There is a Single Requirement

                            If Not Requirementlist(Requirement).ToString().Contains("AND") Then
                                '-------------------------------------------
                                'One Group Listed and One Member
                                '-------------------------------------------
                                lvNewRule = New SybrinMandate.Rule

                                lvReq = New SybrinMandate.Requirement
                                lvReq.Concatenator = manConcatenator.concatAnd
                                lvReq.OccurenceCount = 1
                                lvReq.OperatorValue = 1

                                'get the Guid associated with this group letter
                                CurGuid = GetGroupGuid(GroupList, Trim(Requirementlist(Requirement).ToString()))

                                If Not CurGuid <> "" Then
                                    WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                                    Return Nothing
                                Else
                                    'Found the Guid for this Group
                                    lvIdent = New SybrinMandate.Identifier
                                    lvIdent.GroupID = CurGuid
                                    lvIdent.IdentityID = CurGuid
                                    lvIdent.IdentityName = "Group " & Trim(Requirementlist(Requirement).ToString())
                                    lvIdent.IdentityType = eIdentityTypes.Group
                                    lvIdent.OccurrenceCount = 1

                                    lvReq.Identifiers.Add(lvIdent)
                                    lvNewRule.Requirements.Add(lvReq)

                                    lvCondition = New SybrinMandate.Condition
                                    lvCondition.FieldNo = "6"
                                    lvCondition.Source = "Amount"
                                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                                    lvCondition.Concatenator = manConcatenator.concatAnd
                                    lvCondition.Depth = 1
                                    lvCondition.Operator = manOperator.opGreaterThanOrEqual
                                    lvCondition.Values.Add(FromAmount)

                                    lvNewRule.Conditions.Add(lvCondition)

                                    lvCondition = New SybrinMandate.Condition
                                    lvCondition.FieldNo = "6"
                                    lvCondition.Source = "Amount"
                                    lvCondition.CompareAsType = eCompareTypes.ctNumber
                                    lvCondition.Concatenator = manConcatenator.concatAnd
                                    lvCondition.Depth = 1
                                    lvCondition.Operator = manOperator.opLessThanOrEqual
                                    lvCondition.Values.Add(ToAmount)

                                    lvNewRule.Conditions.Add(lvCondition)
                                    lvMandate.Rules.Add(lvNewRule)

                                End If

                            Else

                                'Multiple Groups Sign Together One Rule Set
                                RequiredGroups = Split(Replace(Requirementlist(Requirement).ToString(), " ", ""), "AND")

                                For GroupCode As Integer = 0 To RequiredGroups.Count - 1
                                    SimpleCount = 0

                                    'get the Guid associated with this group letter
                                    CurGuid = GetGroupGuid(GroupList, RequiredGroups(GroupCode).ToString())

                                    If Not CurGuid <> "" Then
                                        WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                                        Return Nothing
                                    Else

                                        'check how many people from this group need to authorise
                                        For Each cha As Char In Replace(Replace(Requirementlist(Requirement).ToString(), " ", ""), "AND", "")
                                            If cha = RequiredGroups(GroupCode).ToString() Then
                                                SimpleCount = SimpleCount + 1
                                            End If
                                        Next

                                        If Not ManAlreadyCounted.Contains(CurGuid) Then
                                            lvReq = New SybrinMandate.Requirement
                                            lvReq.OccurenceCount = 1
                                            lvReq.Concatenator = manConcatenator.concatAnd

                                            'Add to indetifier
                                            lvIdent = New SybrinMandate.Identifier
                                            lvIdent.GroupID = CurGuid
                                            lvIdent.IdentityID = CurGuid
                                            lvIdent.IdentityName = "Group " & RequiredGroups(GroupCode).ToString()
                                            lvIdent.IdentityType = eIdentityTypes.Group
                                            lvIdent.OccurrenceCount = 1
                                            lvReq.OperatorValue = CType(SimpleCount, Short)

                                            'already counted this Group
                                            ManAlreadyCounted.Add(CurGuid)

                                            lvReq.Identifiers.Add(lvIdent)
                                            lvNewRule.Requirements.Add(lvReq)
                                        End If

                                    End If

                                Next


                                lvCondition = New SybrinMandate.Condition
                                lvCondition.FieldNo = "6"
                                lvCondition.Source = "Amount"
                                lvCondition.CompareAsType = eCompareTypes.ctNumber
                                lvCondition.Concatenator = manConcatenator.concatAnd
                                lvCondition.Depth = 1
                                lvCondition.Operator = manOperator.opGreaterThanOrEqual
                                lvCondition.Values.Add(FromAmount)

                                lvNewRule.Conditions.Add(lvCondition)

                                lvCondition = New SybrinMandate.Condition
                                lvCondition.FieldNo = "6"
                                lvCondition.Source = "Amount"
                                lvCondition.CompareAsType = eCompareTypes.ctNumber
                                lvCondition.Concatenator = manConcatenator.concatAnd
                                lvCondition.Depth = 1
                                lvCondition.Operator = manOperator.opLessThanOrEqual
                                lvCondition.Values.Add(ToAmount)

                                lvNewRule.Conditions.Add(lvCondition)
                                lvMandate.Rules.Add(lvNewRule)
                                ManAlreadyCounted.Clear()

                            End If


                        Else

                            'check if there are 2x single group requirements in one Rule
                            If RuleDescription.Contains("AND") = False And RuleDescription.Contains("OR") = True Then

                                'There are a series of single groups to sign
                                lvNewRule = New SybrinMandate.Rule

                                lvReq = New SybrinMandate.Requirement
                                lvReq.Concatenator = manConcatenator.concatAnd

                                lvReq.OccurenceCount = 1

                                RequiredGroups = Split(Replace(RuleDescription, " ", ""), "OR")

                                For GroupCode As Integer = 0 To RequiredGroups.Count - 1
                                    SimpleCount = 0

                                    'get the Guid associated with this group letter
                                    CurGuid = GetGroupGuid(GroupList, RequiredGroups(GroupCode).ToString())

                                    If Not CurGuid <> "" Then
                                        WriteLog("Unable to Find Guid for Provided Group: '" & CurGuid.ToString() & "'")
                                        Return Nothing
                                    Else

                                        'check how many people from this group need to authorise
                                        For Each cha As Char In Replace(Replace(RuleDescription, " ", ""), "AND", "")
                                            If cha = RequiredGroups(GroupCode).ToString() Then
                                                SimpleCount = SimpleCount + 1
                                            End If
                                        Next

                                        'Found the Guid for this Group
                                        lvIdent = New SybrinMandate.Identifier
                                        lvIdent.GroupID = CurGuid
                                        lvIdent.IdentityID = CurGuid
                                        lvIdent.IdentityName = "Group " & RequiredGroups(GroupCode).ToString()
                                        lvIdent.IdentityType = eIdentityTypes.Group
                                        lvIdent.OccurrenceCount = SimpleCount
                                        lvReq.OperatorValue = CType(SimpleCount, Short)


                                        lvReq.Identifiers.Add(lvIdent)

                                    End If

                                Next

                                lvNewRule.Requirements.Add(lvReq)
                                'reset them for each Rule that is finalized

                                lvCondition = New SybrinMandate.Condition
                                lvCondition.FieldNo = "6"
                                lvCondition.Source = "Amount"
                                lvCondition.CompareAsType = eCompareTypes.ctNumber
                                lvCondition.Concatenator = manConcatenator.concatAnd
                                lvCondition.Depth = 1
                                lvCondition.Operator = manOperator.opGreaterThanOrEqual
                                lvCondition.Values.Add(FromAmount)

                                lvNewRule.Conditions.Add(lvCondition)

                                lvCondition = New SybrinMandate.Condition
                                lvCondition.FieldNo = "6"
                                lvCondition.Source = "Amount"
                                lvCondition.CompareAsType = eCompareTypes.ctNumber
                                lvCondition.Concatenator = manConcatenator.concatAnd
                                lvCondition.Depth = 1
                                lvCondition.Operator = manOperator.opLessThanOrEqual
                                lvCondition.Values.Add(ToAmount)

                                lvNewRule.Conditions.Add(lvCondition)
                                lvMandate.Rules.Add(lvNewRule)
                            End If
                        End If

                    Next

                End If

            End If

            'Pass the object back.
            Return lvMandate

        Catch ex As Exception
            WriteLog("An error occured in Convert Mandate Rule" & vbCrLf & ex.ToString())
            Return Nothing
        End Try

    End Function

    Private Sub txtSourceConn_TextChanged(sender As Object, e As EventArgs) Handles txtSourceConn.TextChanged

    End Sub
End Class
